"""Games page – proper game detection, live system metrics, session tracking."""
import time
from PySide6.QtCore    import Qt, QTimer
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                                QFrame, QScrollArea, QPushButton)

from .. import theme as T
from ..widgets import (StatCard, MultiLineChart, ChartLegend, Panel,
                        link_label, small_dropdown, info_row, ToggleSwitch)
from .dashboard import scrollable


class _GameCard(QFrame):
    """A live game card showing name, process, CPU/RAM, session time."""
    def __init__(self, game: dict, parent=None):
        super().__init__(parent)
        self.setStyleSheet(
            f"QFrame {{ background:{T.CARD_BG_2}; border:1px solid {T.BORDER};"
            f"border-radius:12px; }}"
        )
        lay = QHBoxLayout(self)
        lay.setContentsMargins(14, 12, 16, 12)
        lay.setSpacing(14)

        # Icon badge
        ic = QLabel(game["icon"])
        ic.setFixedSize(44, 44)
        ic.setAlignment(Qt.AlignCenter)
        ic.setStyleSheet(
            f"background:{game['color']}; color:white; font-size:18px;"
            f"font-weight:700; border-radius:10px;"
        )
        lay.addWidget(ic)

        # Info
        info = QVBoxLayout(); info.setSpacing(3)
        name_lbl = QLabel(game["name"])
        name_lbl.setStyleSheet(f"color:{T.TEXT_PRIMARY}; font-size:14px; font-weight:700;")
        proc_lbl = QLabel(game["proc"])
        proc_lbl.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:11px;")
        status = QHBoxLayout()
        dot = QLabel("●"); dot.setStyleSheet(f"color:{T.ACCENT_GREEN}; font-size:9px;")
        st  = QLabel("Running")
        st.setStyleSheet(f"color:{T.ACCENT_GREEN}; font-size:11px; font-weight:600;")
        status.addWidget(dot); status.addWidget(st); status.addStretch(1)
        info.addWidget(name_lbl); info.addWidget(proc_lbl); info.addLayout(status)
        lay.addLayout(info, 1)

        # CPU/RAM
        self._cpu_lbl = QLabel(f"{game['cpu']:.1f}%")
        self._cpu_lbl.setAlignment(Qt.AlignRight)
        self._cpu_lbl.setStyleSheet(f"color:{T.ACCENT_PURPLE}; font-size:14px; font-weight:700;")
        self._mem_lbl = QLabel(f"{game['mem']:.1f}% RAM")
        self._mem_lbl.setAlignment(Qt.AlignRight)
        self._mem_lbl.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:11px;")
        right = QVBoxLayout(); right.setSpacing(2)
        right.addWidget(self._cpu_lbl); right.addWidget(self._mem_lbl)
        lay.addLayout(right)

    def refresh(self, cpu: float, mem: float):
        self._cpu_lbl.setText(f"{cpu:.1f}%")
        self._mem_lbl.setText(f"{mem:.1f}% RAM")


class GamesPage(QWidget):
    title    = "Games"
    subtitle = "Real-time game detection & system performance"

    def __init__(self, parent=None):
        super().__init__(parent)
        outer = QVBoxLayout(self); outer.setContentsMargins(0, 0, 0, 0)
        body  = QWidget()
        self._lay = QVBoxLayout(body)
        self._lay.setContentsMargins(4, 4, 4, 4); self._lay.setSpacing(18)

        # ── Stat cards ─────────────────────────────────────────────────────
        stats = QHBoxLayout(); stats.setSpacing(16)
        self._card_status = StatCard("🎮", T.ACCENT_PINK,   "Status",    "Idle",  "No game running",  [0]*12)
        self._card_cpu    = StatCard("🖥", T.ACCENT_PURPLE, "CPU",       "—%",    "System total",     [0]*12)
        self._card_ram    = StatCard("💾", T.ACCENT_BLUE,   "RAM",       "— GB",  "In use",           [0]*12)
        self._card_gpu    = StatCard("◎", T.ACCENT_TEAL,   "GPU",       "—%",    "Utilisation",      [0]*12)
        self._card_ping   = StatCard("🌐", T.ACCENT_ORANGE, "Network",   "— ms",  "Ping",             [0]*12)
        for c in (self._card_status, self._card_cpu, self._card_ram,
                  self._card_gpu, self._card_ping):
            stats.addWidget(c)
        self._lay.addLayout(stats)

        # ── Middle: chart + detected games ─────────────────────────────────
        mid = QHBoxLayout(); mid.setSpacing(18)

        chart_panel = Panel("Live System Load", small_dropdown("60 s"))
        chart_panel.body.addWidget(ChartLegend([
            ("CPU %", T.ACCENT_PURPLE), ("RAM %", T.ACCENT_BLUE),
        ]))
        self._chart = MultiLineChart(
            [{"name":"CPU %","color":T.ACCENT_PURPLE,"data":[0]*60},
             {"name":"RAM %","color":T.ACCENT_BLUE,  "data":[0]*60}],
            [], y_max=100)
        chart_panel.body.addWidget(self._chart)
        mid.addWidget(chart_panel, 3)

        # Running games panel
        self._games_panel = Panel("Detected Games & Launchers")
        self._games_container = QVBoxLayout()
        self._no_game_lbl = QLabel(
            "🎮  No games detected running right now.\n\n"
            "Start a game — inputX will detect it automatically."
        )
        self._no_game_lbl.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:12px;")
        self._no_game_lbl.setWordWrap(True)
        self._games_container.addWidget(self._no_game_lbl)
        self._games_panel.body.addLayout(self._games_container)
        self._games_panel.body.addStretch(1)
        mid.addWidget(self._games_panel, 2)
        self._lay.addLayout(mid)

        # ── Bottom: game settings + process table ───────────────────────────
        bottom = QHBoxLayout(); bottom.setSpacing(18)

        settings_panel = Panel("Gaming Settings")
        self._toggles = {}
        for icon, key, title_, sub, on in [
            ("⚡","game_mode",  "Game Mode",    "Prioritise performance", True),
            ("🖥","overlay",    "FPS Overlay",  "Show overlay in games",  True),
            ("📸","capture",    "Auto Capture", "Capture key moments",    False),
            ("🔕","notifs",     "Mute Alerts",  "Silence while in game",  True),
        ]:
            row = QHBoxLayout()
            ic = QLabel(icon); ic.setFixedSize(30,30); ic.setAlignment(Qt.AlignCenter)
            ic.setStyleSheet(f"background:{T.CARD_BG_2}; border-radius:8px; font-size:13px;")
            row.addWidget(ic)
            col = QVBoxLayout(); col.setSpacing(2)
            t = QLabel(title_); t.setStyleSheet(f"color:{T.TEXT_PRIMARY}; font-size:12px; font-weight:600;")
            s = QLabel(sub); s.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:10px;")
            col.addWidget(t); col.addWidget(s); row.addLayout(col,1)
            tog = ToggleSwitch(on)
            self._toggles[key] = tog
            row.addWidget(tog)
            settings_panel.body.addLayout(row)
        settings_panel.body.addStretch(1)
        bottom.addWidget(settings_panel, 1)

        # All-processes table (top 10 by CPU)
        self._procs_panel = Panel("Top Processes")
        self._proc_rows = []
        hdr = QHBoxLayout()
        for txt, w in [("Process",0),("CPU%",52),("RAM%",52)]:
            l = QLabel(txt); l.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:10px; font-weight:600;")
            if w: l.setFixedWidth(w); l.setAlignment(Qt.AlignRight)
            hdr.addWidget(l, 0 if w else 1)
        self._procs_panel.body.addLayout(hdr)
        for i in range(10):
            row = QHBoxLayout()
            nm  = QLabel("—"); nm.setStyleSheet(f"color:{T.TEXT_PRIMARY}; font-size:11px;")
            cpu = QLabel("—"); cpu.setFixedWidth(52); cpu.setAlignment(Qt.AlignRight)
            cpu.setStyleSheet(f"color:{T.ACCENT_PURPLE}; font-size:11px; font-weight:600;")
            mem = QLabel("—"); mem.setFixedWidth(52); mem.setAlignment(Qt.AlignRight)
            mem.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:11px;")
            row.addWidget(nm,1); row.addWidget(cpu); row.addWidget(mem)
            self._procs_panel.body.addLayout(row)
            self._proc_rows.append((nm, cpu, mem))
        self._procs_panel.body.addStretch(1)
        bottom.addWidget(self._procs_panel, 1)
        self._lay.addLayout(bottom)

        self._lay.addStretch(1)
        outer.addWidget(scrollable(body))

        # State
        self._active_cards = {}   # game_name -> _GameCard
        self._session_start_map = {}  # game_name -> start time

    def on_snapshot(self, snap: dict):
        cpu = snap["cpu_pct"]; ram = snap["ram_pct"]
        used = snap["ram_used"]; total = snap["ram_total"]

        # Cards
        self._card_cpu.update_live(f"{cpu:.1f}%",          "system", snap["cpu_hist"][-12:])
        self._card_ram.update_live(f"{used}/{total} GB",   "in use", snap["ram_hist"][-12:])
        self._card_gpu.update_live(f"{snap['gpu_pct']}%",  "GPU",    [snap["gpu_pct"]]*12)
        self._card_ping.update_live(f"{snap['ping_ms']} ms","ping",  snap["ping_hist"][-12:])

        games = snap.get("running_games", [])
        if games:
            self._card_status.update_live(games[0]["name"], "playing", [6]*12)
        else:
            self._card_status.update_live("Idle", "no game", [0]*12)

        # Chart
        self._chart.update_series([
            {"name":"CPU %","color":T.ACCENT_PURPLE,"data":snap["cpu_hist"]},
            {"name":"RAM %","color":T.ACCENT_BLUE,  "data":snap["ram_hist"]},
        ])

        # Game cards
        current_names = {g["name"] for g in games}
        existing = set(self._active_cards.keys())

        # Remove gone games
        for name in existing - current_names:
            card = self._active_cards.pop(name)
            card.setParent(None); card.deleteLater()
            self._session_start_map.pop(name, None)

        # Add new games
        for g in games:
            if g["name"] not in self._active_cards:
                self._session_start_map.setdefault(g["name"], time.time())
                card = _GameCard(g)
                self._active_cards[g["name"]] = card
                self._games_container.addWidget(card)
            else:
                # Update existing
                self._active_cards[g["name"]].refresh(g["cpu"], g["mem"])

        if current_names:
            self._no_game_lbl.hide()
        else:
            self._no_game_lbl.show()

        # Process table
        procs = snap.get("top_procs", [])
        for i, (nm, cpu_l, mem_l) in enumerate(self._proc_rows):
            if i < len(procs):
                n, c, m = procs[i]
                nm.setText(n[:28])
                cpu_l.setText(f"{c:.1f}%")
                mem_l.setText(f"{m:.1f}%")
            else:
                nm.setText("—"); cpu_l.setText("—"); mem_l.setText("—")
