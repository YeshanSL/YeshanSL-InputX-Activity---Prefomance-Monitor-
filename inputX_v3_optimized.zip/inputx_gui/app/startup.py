"""
startup.py – register / unregister inputX as a login-time startup program.

Supports:
  Windows  – HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run
  macOS    – ~/Library/LaunchAgents/com.inputx.plist
  Linux    – ~/.config/autostart/inputx.desktop
"""
import sys
import os
import platform

APP_NAME = "inputX"


def _exe():
    """Return the path that should be launched at startup."""
    if getattr(sys, "frozen", False):
        # PyInstaller bundle
        return sys.executable
    # Running as a plain .py script
    return f'"{sys.executable}" "{os.path.abspath(sys.argv[0])}"'


# ── Windows ───────────────────────────────────────────────────────────────────
def _win_is_enabled():
    try:
        import winreg
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                             r"Software\Microsoft\Windows\CurrentVersion\Run")
        winreg.QueryValueEx(key, APP_NAME)
        winreg.CloseKey(key)
        return True
    except Exception:
        return False


def _win_enable():
    try:
        import winreg
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                             r"Software\Microsoft\Windows\CurrentVersion\Run",
                             0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(key, APP_NAME, 0, winreg.REG_SZ, _exe())
        winreg.CloseKey(key)
        return True
    except Exception as e:
        print(f"[startup] Windows enable failed: {e}")
        return False


def _win_disable():
    try:
        import winreg
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                             r"Software\Microsoft\Windows\CurrentVersion\Run",
                             0, winreg.KEY_SET_VALUE)
        winreg.DeleteValue(key, APP_NAME)
        winreg.CloseKey(key)
        return True
    except Exception:
        return False


# ── macOS ─────────────────────────────────────────────────────────────────────
def _mac_plist_path():
    return os.path.expanduser("~/Library/LaunchAgents/com.inputx.plist")


def _mac_is_enabled():
    return os.path.exists(_mac_plist_path())


def _mac_enable():
    exe = _exe()
    content = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>com.inputx</string>
  <key>ProgramArguments</key>
  <array>
    {"".join(f"<string>{a}</string>" for a in exe.split())}
  </array>
  <key>RunAtLoad</key>
  <true/>
</dict>
</plist>
"""
    try:
        os.makedirs(os.path.dirname(_mac_plist_path()), exist_ok=True)
        with open(_mac_plist_path(), "w") as f:
            f.write(content)
        os.system(f"launchctl load {_mac_plist_path()}")
        return True
    except Exception as e:
        print(f"[startup] macOS enable failed: {e}")
        return False


def _mac_disable():
    try:
        os.system(f"launchctl unload {_mac_plist_path()}")
        os.remove(_mac_plist_path())
        return True
    except Exception:
        return False


# ── Linux / XDG autostart ─────────────────────────────────────────────────────
def _linux_desktop_path():
    return os.path.expanduser("~/.config/autostart/inputx.desktop")


def _linux_is_enabled():
    return os.path.exists(_linux_desktop_path())


def _linux_enable():
    content = f"""[Desktop Entry]
Type=Application
Name={APP_NAME}
Exec={_exe()}
Hidden=false
NoDisplay=false
X-GNOME-Autostart-enabled=true
Comment=inputX Performance Monitoring & Analytics
"""
    try:
        os.makedirs(os.path.dirname(_linux_desktop_path()), exist_ok=True)
        with open(_linux_desktop_path(), "w") as f:
            f.write(content)
        return True
    except Exception as e:
        print(f"[startup] Linux enable failed: {e}")
        return False


def _linux_disable():
    try:
        os.remove(_linux_desktop_path())
        return True
    except Exception:
        return False


# ── Public API ────────────────────────────────────────────────────────────────
_os = platform.system()


def is_enabled() -> bool:
    if _os == "Windows":
        return _win_is_enabled()
    elif _os == "Darwin":
        return _mac_is_enabled()
    else:
        return _linux_is_enabled()


def enable() -> bool:
    if _os == "Windows":
        return _win_enable()
    elif _os == "Darwin":
        return _mac_enable()
    else:
        return _linux_enable()


def disable() -> bool:
    if _os == "Windows":
        return _win_disable()
    elif _os == "Darwin":
        return _mac_disable()
    else:
        return _linux_disable()


def set_enabled(state: bool) -> bool:
    return enable() if state else disable()
