import os
from PySide6.QtCore import Qt, Signal
from PySide6.QtGui  import QFont, QPixmap
from PySide6.QtWidgets import (QWidget, QLabel, QVBoxLayout, QHBoxLayout,
                                QPushButton, QFrame, QSizePolicy)

from . import theme as T
from .widgets import soft_shadow


NAV_ITEMS = [
    ("Dashboard",  "▦"),
    ("Mouse",      "🖱"),
    ("Keyboard",   "⌨"),
    ("Controller", "🎮"),
    ("Network",    "🌐"),
    ("Games",      "🎯"),
    ("Settings",   "⚙"),
]


def _logo_path():
    here = os.path.dirname(__file__)
    candidates = [
        os.path.join(here, "..", "inputx_logo.png"),
        os.path.join(here, "inputx_logo.png"),
    ]
    for p in candidates:
        if os.path.exists(os.path.normpath(p)):
            return os.path.normpath(p)
    return None


class NavButton(QPushButton):
    def __init__(self, icon, text, parent=None):
        super().__init__(parent)
        self.setCheckable(True)
        self.setCursor(Qt.PointingHandCursor)
        self.setFixedHeight(42)
        self.setText(f"  {icon}   {text}")
        self.setStyleSheet(self._style(False))

    def setChecked(self, checked):
        super().setChecked(checked)
        self.setStyleSheet(self._style(checked))

    def _style(self, active):
        if active:
            return f"""
                QPushButton {{
                    text-align:left; padding-left:14px; border-radius:10px;
                    color:white; font-size:13px; font-weight:600;
                    background-color: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                        stop:0 {T.SIDEBAR_ACTIVE_GRAD[0]},
                        stop:1 {T.SIDEBAR_ACTIVE_GRAD[1]});
                }}"""
        return f"""
            QPushButton {{
                text-align:left; padding-left:14px; border-radius:10px;
                color:{T.TEXT_SECOND}; font-size:13px; font-weight:500;
                background-color:transparent;
            }}
            QPushButton:hover {{
                background-color:{T.CARD_BG_2}; color:{T.TEXT_PRIMARY};
            }}"""


class Sidebar(QWidget):
    page_changed = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedWidth(220)
        self.setStyleSheet(
            f"background-color:{T.SIDEBAR_BG}; border-right:1px solid {T.BORDER_SOFT};"
        )
        lay = QVBoxLayout(self)
        lay.setContentsMargins(18, 22, 18, 18)
        lay.setSpacing(4)

        # ---- Logo ----
        logo_row = QHBoxLayout()
        logo_path = _logo_path()
        if logo_path:
            logo_px = QPixmap(logo_path).scaled(
                32, 32, Qt.KeepAspectRatio, Qt.SmoothTransformation
            )
            logo_mark = QLabel()
            logo_mark.setPixmap(logo_px)
            logo_mark.setFixedSize(32, 32)
        else:
            logo_mark = QLabel("X")
            logo_mark.setFixedSize(30, 30)
            logo_mark.setAlignment(Qt.AlignCenter)
            logo_mark.setStyleSheet(f"""
                background-color: qlineargradient(x1:0,y1:0,x2:1,y2:1,
                    stop:0 {T.ACCENT_PURPLE}, stop:1 {T.ACCENT_BLUE});
                color:white; font-weight:800; font-size:16px; border-radius:8px;
            """)

        logo_text = QLabel("inputX")
        logo_text.setStyleSheet("color:white; font-size:18px; font-weight:700;")
        logo_row.addWidget(logo_mark)
        logo_row.addWidget(logo_text)
        logo_row.addStretch(1)
        lay.addLayout(logo_row)
        lay.addSpacing(26)

        self.buttons = {}
        for name, icon in NAV_ITEMS:
            btn = NavButton(icon, name)
            btn.clicked.connect(lambda checked, n=name: self._select(n))
            lay.addWidget(btn)
            self.buttons[name] = btn

        lay.addStretch(1)

        # Recording status card
        rec_card = QFrame()
        rec_card.setStyleSheet(
            f"background-color:{T.CARD_BG}; border:1px solid {T.BORDER}; border-radius:12px;"
        )
        rl = QVBoxLayout(rec_card)
        rl.setContentsMargins(14, 12, 14, 12)
        rl.setSpacing(4)
        row = QHBoxLayout()
        dot = QLabel("●")
        dot.setStyleSheet(f"color:{T.ACCENT_GREEN}; font-size:10px;")
        rec_title = QLabel("Recording Status")
        rec_title.setStyleSheet(f"color:{T.TEXT_SECOND}; font-size:11px;")
        row.addWidget(dot); row.addWidget(rec_title); row.addStretch(1)
        rl.addLayout(row)
        active_lbl = QLabel("Active")
        active_lbl.setStyleSheet(f"color:{T.ACCENT_GREEN}; font-size:14px; font-weight:700;")
        rl.addWidget(active_lbl)
        mon_lbl = QLabel("Monitoring all activities")
        mon_lbl.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:10px;")
        rl.addWidget(mon_lbl)
        lay.addWidget(rec_card)

        # Uptime card
        uptime_card = QFrame()
        uptime_card.setStyleSheet(
            f"background-color:{T.CARD_BG}; border:1px solid {T.BORDER}; border-radius:12px;"
        )
        ul = QVBoxLayout(uptime_card)
        ul.setContentsMargins(14, 12, 14, 12)
        ul.setSpacing(4)
        ut_title = QLabel("⏱  Session Uptime")
        ut_title.setStyleSheet(f"color:{T.TEXT_SECOND}; font-size:11px;")
        ul.addWidget(ut_title)
        self._uptime_val = QLabel("00h 00m 00s")
        self._uptime_val.setStyleSheet(
            f"color:{T.TEXT_PRIMARY}; font-size:14px; font-weight:700;"
        )
        ul.addWidget(self._uptime_val)
        lay.addWidget(uptime_card)
        lay.addSpacing(8)

        bottom_row = QHBoxLayout()
        ver = QLabel("🛡 v2.0.0")
        ver.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:11px;")
        bottom_row.addWidget(ver)
        bottom_row.addStretch(1)
        lay.addLayout(bottom_row)

        self._select("Dashboard")

    def _select(self, name):
        for n, b in self.buttons.items():
            b.setChecked(n == name)
        self.page_changed.emit(name)

    def update_uptime(self, text: str):
        self._uptime_val.setText(text)


class TopHeader(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)

        left = QVBoxLayout()
        left.setSpacing(4)
        self.title_lbl = QLabel("Good Evening, User  👋")
        self.title_lbl.setStyleSheet("color:white; font-size:24px; font-weight:700;")
        self.sub_lbl   = QLabel("Here's your system activity overview")
        self.sub_lbl.setStyleSheet(f"color:{T.TEXT_SECOND}; font-size:13px;")
        left.addWidget(self.title_lbl)
        left.addWidget(self.sub_lbl)
        lay.addLayout(left)
        lay.addStretch(1)

        date_card = QFrame()
        date_card.setStyleSheet(
            f"background-color:{T.CARD_BG}; border:1px solid {T.BORDER}; border-radius:12px;"
        )
        dl = QHBoxLayout(date_card)
        dl.setContentsMargins(16, 12, 16, 12)
        dl.setSpacing(10)
        icon = QLabel("📅")
        icon.setStyleSheet("font-size:16px;")
        dl.addWidget(icon)
        txt = QVBoxLayout(); txt.setSpacing(2)
        self._date_lbl = QLabel("—")
        self._date_lbl.setStyleSheet(
            f"color:{T.TEXT_PRIMARY}; font-size:13px; font-weight:600;"
        )
        self._day_lbl = QLabel("—")
        self._day_lbl.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:11px;")
        txt.addWidget(self._date_lbl)
        txt.addWidget(self._day_lbl)
        dl.addLayout(txt)
        self._time_lbl = QLabel("—")
        self._time_lbl.setStyleSheet(
            f"color:{T.ACCENT_BLUE}; font-size:16px; font-weight:700;"
        )
        dl.addWidget(self._time_lbl)
        lay.addWidget(date_card)

    def set_titles(self, title, subtitle):
        self.title_lbl.setText(title)
        self.sub_lbl.setText(subtitle)

    def update_datetime(self, snap: dict):
        self._date_lbl.setText(snap.get("date_str", "—"))
        self._day_lbl.setText(snap.get("day_str", "—"))
        self._time_lbl.setText(snap.get("time_str", "—"))

        hour = snap.get("hour", 12)
        if 5 <= hour < 12:
            greet = "Good Morning"
        elif 12 <= hour < 17:
            greet = "Good Afternoon"
        elif 17 <= hour < 21:
            greet = "Good Evening"
        else:
            greet = "Good Night"
        self.title_lbl.setText(f"{greet}, User  👋")
