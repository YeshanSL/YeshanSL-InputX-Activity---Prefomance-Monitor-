"""
Reusable widgets – optimised for smooth 1 Hz live updates.

Key improvements over v1:
- StatCard stores val/delta/spark references directly at construction time
  (no fragile layout-index walking at update time)
- MultiLineChart uses cubic bezier smoothing + dirty-flag to skip repaints
  when data hasn't changed
- All QPainter calls use setRenderHints once at top
- ToggleSwitch.isChecked() works properly
- CircularGauge has smooth glow
- DonutChart handles zero-total gracefully
"""
import math
from PySide6.QtCore  import Qt, QRectF, QPointF, QSize
from PySide6.QtGui   import (QPainter, QColor, QLinearGradient, QPen, QBrush,
                               QFont, QPainterPath, QRadialGradient, QConicalGradient)
from PySide6.QtWidgets import (QWidget, QLabel, QHBoxLayout, QVBoxLayout, QFrame,
                                 QGraphicsDropShadowEffect, QSizePolicy, QGridLayout)
from . import theme as T


# ── Helpers ───────────────────────────────────────────────────────────────────
def make_card(radius=T.CARD_RADIUS, bg=T.CARD_BG, border=T.BORDER):
    f = QFrame()
    f.setStyleSheet(f"QFrame {{ background-color:{bg}; border:1px solid {border}; border-radius:{radius}px; }}")
    return f


def soft_shadow(widget, blur=14, color=QColor(0,0,0,90), dx=0, dy=3):
    """
    PERF: QGraphicsDropShadowEffect rasterizes its ENTIRE source widget
    (and all descendants) to an offscreen buffer on every repaint of any
    child. Apply this only to static, childless background frames — never
    to a widget whose children update on a timer (sparklines, charts,
    heatmaps) or the effect will silently re-render the whole subtree
    every tick and stutter on integrated-GPU laptops.
    """
    eff = QGraphicsDropShadowEffect(widget)
    eff.setBlurRadius(blur); eff.setColor(color); eff.setOffset(dx, dy)
    widget.setGraphicsEffect(eff)


# ── Sparkline ─────────────────────────────────────────────────────────────────
class Sparkline(QWidget):
    def __init__(self, data, color="#7c6cf0", parent=None):
        super().__init__(parent)
        self.data  = list(data)
        self.color = QColor(color)
        self.setMinimumHeight(34)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

    def paintEvent(self, ev):
        if len(self.data) < 2:
            return
        p = QPainter(self)
        p.setRenderHints(QPainter.Antialiasing | QPainter.SmoothPixmapTransform)
        w, h  = self.width(), self.height()
        data  = self.data
        lo, hi = min(data), max(data)
        rng   = (hi - lo) or 1
        pad   = 3
        step  = (w - 2*pad) / (len(data) - 1)

        pts = [QPointF(pad + i*step, h - pad - (v-lo)/rng*(h-2*pad))
               for i, v in enumerate(data)]

        # gradient fill
        path = QPainterPath()
        path.moveTo(pts[0].x(), h)
        for pt in pts: path.lineTo(pt)
        path.lineTo(pts[-1].x(), h)
        path.closeSubpath()
        grad = QLinearGradient(0, 0, 0, h)
        c1 = QColor(self.color); c1.setAlpha(70)
        c2 = QColor(self.color); c2.setAlpha(0)
        grad.setColorAt(0, c1); grad.setColorAt(1, c2)
        p.fillPath(path, QBrush(grad))

        # smooth line
        line = QPainterPath()
        line.moveTo(pts[0])
        for i in range(1, len(pts)):
            prev, cur = pts[i-1], pts[i]
            cp1 = QPointF((prev.x()+cur.x())/2, prev.y())
            cp2 = QPointF((prev.x()+cur.x())/2, cur.y())
            line.cubicTo(cp1, cp2, cur)
        pen = QPen(self.color, 2.0); pen.setJoinStyle(Qt.RoundJoin); pen.setCapStyle(Qt.RoundCap)
        p.setPen(pen); p.drawPath(line)


# ── StatCard ──────────────────────────────────────────────────────────────────
class StatCard(QWidget):
    """Icon + title + big value + delta + sparkline.

    Structure: a static background QFrame (carries the drop-shadow) sits
    behind a transparent content layer that updates every tick. Because
    the background frame has no children, its shadow never has to be
    re-rasterized when the sparkline/value update — only the cheap
    content layer repaints.
    """
    def __init__(self, icon_char, icon_bg, title, value, delta, spark_data,
                 spark_color=None, up=True, parent=None):
        super().__init__(parent)
        grid = QGridLayout(self)
        grid.setContentsMargins(0, 0, 0, 0)

        bg = QFrame()
        bg.setObjectName("statcard_bg")
        bg.setStyleSheet(f"""
            QFrame#statcard_bg {{
                background-color:{T.CARD_BG};
                border:1px solid {T.BORDER};
                border-radius:{T.CARD_RADIUS}px;
            }}
        """)
        soft_shadow(bg)
        grid.addWidget(bg, 0, 0)

        content = QWidget()
        content.setStyleSheet("background: transparent;")
        lay = QVBoxLayout(content)
        lay.setContentsMargins(18, 16, 18, 14)
        lay.setSpacing(8)

        top = QHBoxLayout(); top.setSpacing(10)
        icon = QLabel(icon_char)
        icon.setFixedSize(40, 40); icon.setAlignment(Qt.AlignCenter)
        icon.setStyleSheet(f"background-color:{icon_bg}33; color:{icon_bg}; border-radius:20px; font-size:17px; font-weight:600;")
        title_lbl = QLabel(title)
        title_lbl.setStyleSheet(f"color:{T.TEXT_SECOND}; font-size:12px;")
        top.addWidget(icon); top.addWidget(title_lbl, 1)
        lay.addLayout(top)

        # Store references directly — no fragile post-hoc searching
        self._val_lbl = QLabel(value)
        self._val_lbl.setStyleSheet(f"color:{T.TEXT_PRIMARY}; font-size:22px; font-weight:700;")
        lay.addWidget(self._val_lbl)

        color = T.UP_COLOR if up else T.DOWN_COLOR
        self._delta_lbl = QLabel(f"↑ {delta}")
        self._delta_lbl.setStyleSheet(f"color:{color}; font-size:11px; font-weight:600;")
        lay.addWidget(self._delta_lbl)

        self._spark = Sparkline(spark_data, spark_color or icon_bg)
        lay.addWidget(self._spark)

        grid.addWidget(content, 0, 0)

    def update_live(self, value: str, delta: str, spark_data: list):
        if self._val_lbl.text() != value:
            self._val_lbl.setText(value)
        if self._delta_lbl.text() != delta:
            self._delta_lbl.setText(delta)
        if self._spark.data != spark_data:
            self._spark.data = list(spark_data)
            self._spark.update()


# ── MultiLineChart ────────────────────────────────────────────────────────────
class MultiLineChart(QWidget):
    """Smooth multi-series chart with bezier curves and dirty-flag repaint."""
    def __init__(self, series, x_labels, y_max=None, y_step=None, parent=None):
        super().__init__(parent)
        self.series   = series
        self.x_labels = x_labels
        self.y_max    = y_max
        self.y_step   = y_step
        self._prev_hash = None
        self.setMinimumHeight(240)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

    def update_series(self, series: list):
        # Only repaint when data actually changed
        h = hash(str([(s["name"], tuple(s["data"])) for s in series]))
        if h == self._prev_hash:
            return
        self._prev_hash = h
        self.series = series
        self.update()

    def paintEvent(self, ev):
        p = QPainter(self)
        p.setRenderHints(QPainter.Antialiasing | QPainter.SmoothPixmapTransform)
        w, h = self.width(), self.height()
        L, R, TOP, BOT = 46, 20, 10, 26
        pw, ph = w - L - R, h - TOP - BOT

        all_vals = [v for s in self.series for v in s["data"]]
        y_max = self.y_max or (max(all_vals) * 1.15 if all_vals else 1) or 1

        # Grid
        grid_pen = QPen(QColor(T.BORDER_SOFT)); grid_pen.setWidthF(0.8)
        font = QFont(T.FONT_FAMILY, 8); p.setFont(font)
        steps = 4
        for i in range(steps + 1):
            y = TOP + ph - (ph * i / steps)
            p.setPen(grid_pen)
            p.drawLine(QPointF(L, y), QPointF(L + pw, y))
            p.setPen(QColor(T.TEXT_MUTED))
            p.drawText(QRectF(0, y-8, L-6, 16), Qt.AlignRight|Qt.AlignVCenter,
                       self._fmt(y_max * i / steps))

        # X labels
        if len(self.x_labels) > 1:
            n = len(self.x_labels)
            for i, lbl in enumerate(self.x_labels):
                x = L + pw * i / (n-1)
                p.setPen(QColor(T.TEXT_MUTED))
                p.drawText(QRectF(x-30, h-BOT+5, 60, 16), Qt.AlignCenter, lbl)

        # Series — smooth bezier
        for s in self.series:
            data  = s["data"]
            color = QColor(s["color"])
            m = len(data)
            if m < 2: continue

            pts = [QPointF(L + pw*i/(m-1),
                           TOP + ph - ph * max(0, min(data[i], y_max)) / y_max)
                   for i in range(m)]

            # Filled area
            area = QPainterPath()
            area.moveTo(pts[0].x(), TOP + ph)
            area.lineTo(pts[0])
            for i in range(1, m):
                prev, cur = pts[i-1], pts[i]
                cp1 = QPointF((prev.x()+cur.x())/2, prev.y())
                cp2 = QPointF((prev.x()+cur.x())/2, cur.y())
                area.cubicTo(cp1, cp2, cur)
            area.lineTo(pts[-1].x(), TOP + ph)
            area.closeSubpath()
            grad = QLinearGradient(0, TOP, 0, TOP+ph)
            c1 = QColor(color); c1.setAlpha(60)
            c2 = QColor(color); c2.setAlpha(3)
            grad.setColorAt(0, c1); grad.setColorAt(1, c2)
            p.fillPath(area, QBrush(grad))

            # Line
            line = QPainterPath()
            line.moveTo(pts[0])
            for i in range(1, m):
                prev, cur = pts[i-1], pts[i]
                cp1 = QPointF((prev.x()+cur.x())/2, prev.y())
                cp2 = QPointF((prev.x()+cur.x())/2, cur.y())
                line.cubicTo(cp1, cp2, cur)
            pen = QPen(color, 2.0)
            pen.setJoinStyle(Qt.RoundJoin); pen.setCapStyle(Qt.RoundCap)
            p.setPen(pen); p.drawPath(line)

            # Dots only at last point
            p.setPen(Qt.NoPen); p.setBrush(QBrush(color))
            p.drawEllipse(pts[-1], 3.5, 3.5)
            inner = QColor("white"); inner.setAlpha(200)
            p.setBrush(QBrush(inner))
            p.drawEllipse(pts[-1], 1.5, 1.5)

    @staticmethod
    def _fmt(v):
        if v >= 1000: return f"{v/1000:.1f}K"
        return f"{v:.0f}"


# ── ChartLegend ───────────────────────────────────────────────────────────────
class ChartLegend(QWidget):
    def __init__(self, items, parent=None):
        super().__init__(parent)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0); lay.setSpacing(16)
        for name, color in items:
            row = QHBoxLayout(); row.setSpacing(6)
            dot = QLabel(); dot.setFixedSize(10, 10)
            dot.setStyleSheet(f"background-color:{color}; border-radius:5px;")
            lbl = QLabel(name); lbl.setStyleSheet(f"color:{T.TEXT_SECOND}; font-size:11px;")
            row.addWidget(dot); row.addWidget(lbl)
            lay.addLayout(row)
        lay.addStretch(1)


# ── DonutChart ────────────────────────────────────────────────────────────────
class DonutChart(QWidget):
    def __init__(self, values, colors, center_title="Total", center_value="0", parent=None):
        super().__init__(parent)
        self.values = values; self.colors = colors
        self.center_title = center_title; self.center_value = center_value
        self.setFixedSize(130, 130)

    def paintEvent(self, ev):
        p = QPainter(self)
        p.setRenderHints(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        m = 10; rect = QRectF(m, m, w-2*m, h-2*m)
        total = sum(self.values) or 1
        angle = 90 * 16
        for v, c in zip(self.values, self.colors):
            span = int(v / total * 360 * 16)
            p.setPen(Qt.NoPen); p.setBrush(QColor(c))
            p.drawPie(rect, angle, -span); angle -= span
        # centre hole
        p.setBrush(QColor(T.CARD_BG)); p.setPen(Qt.NoPen)
        inner = 0.62
        ir = QRectF(w*(1-inner)/2, h*(1-inner)/2, w*inner, h*inner)
        p.drawEllipse(ir)
        # text
        p.setPen(QColor(T.TEXT_MUTED))
        p.setFont(QFont(T.FONT_FAMILY, 8)); p.drawText(QRectF(0,h/2-20,w,16), Qt.AlignCenter, self.center_title)
        p.setPen(QColor(T.TEXT_PRIMARY))
        p.setFont(QFont(T.FONT_FAMILY, 10, QFont.Bold))
        p.drawText(QRectF(0,h/2-4,w,18), Qt.AlignCenter, self.center_value)


# ── HeatmapWidget ─────────────────────────────────────────────────────────────
class HeatmapWidget(QWidget):
    def __init__(self, blobs=None, parent=None):
        super().__init__(parent)
        self.blobs = blobs or self._default_blobs()
        self.setMinimumHeight(160)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

    def _default_blobs(self):
        import random; random.seed(42)
        return [(random.random(), random.random(), random.random()*0.4+0.1) for _ in range(20)]

    def _color_for(self, t):
        stops = [(0,(20,20,50)),(0.3,(80,0,120)),(0.6,(200,60,0)),(1.0,(255,200,0))]
        for i in range(len(stops)-1):
            t0,c0=stops[i]; t1,c1=stops[i+1]
            if t0<=t<=t1:
                f=(t-t0)/(t1-t0) if t1>t0 else 0
                return tuple(int(c0[j]+(c1[j]-c0[j])*f) for j in range(3))
        return stops[-1][1]

    def paintEvent(self, ev):
        p = QPainter(self)
        p.setRenderHints(QPainter.Antialiasing|QPainter.SmoothPixmapTransform)
        w, h = self.width(), self.height()
        p.fillRect(0, 0, w, h, QColor(T.CARD_BG_2))
        for rx, ry, intensity in self.blobs:
            x, y = rx*w, ry*h
            radius = intensity * min(w,h) * 0.35
            grad = QRadialGradient(x, y, radius)
            r,g,b = self._color_for(intensity)
            c1 = QColor(r,g,b,int(200*intensity))
            c2 = QColor(r,g,b,0)
            grad.setColorAt(0, c1); grad.setColorAt(1, c2)
            p.setPen(Qt.NoPen); p.setBrush(QBrush(grad))
            p.drawEllipse(QPointF(x,y), radius, radius)


class HeatmapLegendBar(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(8)

    def paintEvent(self, ev):
        p = QPainter(self)
        grad = QLinearGradient(0,0,self.width(),0)
        grad.setColorAt(0,   QColor(20,20,50))
        grad.setColorAt(0.3, QColor(80,0,120))
        grad.setColorAt(0.6, QColor(200,60,0))
        grad.setColorAt(1.0, QColor(255,200,0))
        path = QPainterPath()
        path.addRoundedRect(0,0,self.width(),self.height(),4,4)
        p.fillPath(path, grad)


# ── ToggleSwitch ──────────────────────────────────────────────────────────────
class ToggleSwitch(QWidget):
    def __init__(self, checked=True, parent=None):
        super().__init__(parent)
        self._checked = checked
        self.setFixedSize(46, 24)
        self.setCursor(Qt.PointingHandCursor)

    def mousePressEvent(self, ev):
        self._checked = not self._checked
        self.update()

    def isChecked(self): return self._checked

    def paintEvent(self, ev):
        p = QPainter(self)
        p.setRenderHints(QPainter.Antialiasing)
        track_color = QColor(T.ACCENT_PURPLE if self._checked else T.BORDER)
        path = QPainterPath()
        path.addRoundedRect(QRectF(0,2,46,20), 10, 10)
        p.fillPath(path, track_color)
        cx = 33 if self._checked else 13
        p.setBrush(QColor("white")); p.setPen(Qt.NoPen)
        p.drawEllipse(QPointF(cx, 12), 9, 9)


# ── BarRow ────────────────────────────────────────────────────────────────────
class BarRow(QWidget):
    def __init__(self, icon_text, icon_bg, name, sub, frac, bar_color,
                 trail, trail_color=None, parent=None):
        super().__init__(parent)
        self._frac = frac; self._bar_color = QColor(bar_color)
        lay = QHBoxLayout(self); lay.setContentsMargins(0,6,0,6); lay.setSpacing(12)
        ic = QLabel(icon_text); ic.setFixedSize(36,36); ic.setAlignment(Qt.AlignCenter)
        ic.setStyleSheet(f"background:{icon_bg}; border-radius:10px; font-size:15px;")
        lay.addWidget(ic)
        mid = QVBoxLayout(); mid.setSpacing(2)
        t = QLabel(name); t.setStyleSheet(f"color:{T.TEXT_PRIMARY}; font-size:13px; font-weight:600;")
        s = QLabel(sub);  s.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:11px;")
        mid.addWidget(t); mid.addWidget(s); lay.addLayout(mid, 1)
        r = QVBoxLayout(); r.setSpacing(2)
        self._trail_lbl = QLabel(trail)
        self._trail_lbl.setStyleSheet(f"color:{trail_color or T.TEXT_PRIMARY}; font-size:12px; font-weight:700;")
        self._trail_lbl.setAlignment(Qt.AlignRight)
        r.addWidget(self._trail_lbl)
        self._bar_container = QWidget(); self._bar_container.setFixedSize(80, 5)
        r.addWidget(self._bar_container)
        lay.addLayout(r)

    def resizeEvent(self, ev):
        w = int(self._bar_container.width() * self._frac)
        self._bar_container.setStyleSheet(
            f"background:{T.BORDER}; border-radius:3px;"
        )


# ── StickRadar ────────────────────────────────────────────────────────────────
class StickRadar(QWidget):
    def __init__(self, x_pct=0, y_pct=0, color=None, parent=None):
        super().__init__(parent)
        self.x_pct = x_pct; self.y_pct = y_pct
        self.color = QColor(color or T.ACCENT_PURPLE)
        self.setFixedSize(100, 100)

    def paintEvent(self, ev):
        p = QPainter(self)
        p.setRenderHints(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        cx, cy, r = w/2, h/2, w/2-4
        # outer ring
        p.setPen(QPen(QColor(T.BORDER), 2)); p.setBrush(Qt.NoBrush)
        p.drawEllipse(QPointF(cx,cy), r, r)
        # crosshairs
        p.setPen(QPen(QColor(T.BORDER_SOFT), 1))
        p.drawLine(QPointF(cx,cy-r), QPointF(cx,cy+r))
        p.drawLine(QPointF(cx-r,cy), QPointF(cx+r,cy))
        # inner zone
        p.setPen(Qt.NoPen)
        c = QColor(self.color); c.setAlpha(30)
        p.setBrush(c); p.drawEllipse(QPointF(cx,cy), r*0.3, r*0.3)
        # dot
        dx = cx + (self.x_pct/100)*r
        dy = cy - (self.y_pct/100)*r
        grad = QRadialGradient(dx, dy, 12)
        c2 = QColor(self.color); c2.setAlpha(255)
        c3 = QColor(self.color); c3.setAlpha(0)
        grad.setColorAt(0, c2); grad.setColorAt(1, c3)
        p.setBrush(QBrush(grad)); p.drawEllipse(QPointF(dx,dy), 12, 12)
        p.setBrush(QColor("white")); p.drawEllipse(QPointF(dx,dy), 5, 5)


# ── SimpleSlider ──────────────────────────────────────────────────────────────
class SimpleSlider(QWidget):
    def __init__(self, value=50, color=None, parent=None):
        super().__init__(parent)
        self.value = value; self.color = QColor(color or T.ACCENT_PURPLE)
        self._cb = None; self.setFixedHeight(20); self.setCursor(Qt.PointingHandCursor)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

    def on_change(self, fn): self._cb = fn

    def _set_from_x(self, x):
        self.value = max(0, min(100, int(x / self.width() * 100)))
        self.update()
        if self._cb: self._cb(self.value)

    def mousePressEvent(self, ev): self._set_from_x(ev.position().x())
    def mouseMoveEvent(self, ev): self._set_from_x(ev.position().x())

    def paintEvent(self, ev):
        p = QPainter(self); p.setRenderHints(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        cy = h//2; track_h = 4; fill_w = int(w * self.value/100)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(T.BORDER)); p.drawRoundedRect(0, cy-track_h//2, w, track_h, 2, 2)
        p.setBrush(self.color); p.drawRoundedRect(0, cy-track_h//2, fill_w, track_h, 2, 2)
        p.setBrush(QColor("white")); p.drawEllipse(QPointF(fill_w, cy), 7, 7)


# ── CircularGauge ─────────────────────────────────────────────────────────────
class CircularGauge(QWidget):
    def __init__(self, pct, color, parent=None):
        super().__init__(parent)
        self.pct = max(0, min(100, pct))
        self.color = QColor(color)
        self.setFixedSize(54, 54)

    def update_pct(self, pct: int):
        p = max(0, min(100, pct))
        if p != self.pct:
            self.pct = p
            self.update()

    def paintEvent(self, ev):
        p = QPainter(self); p.setRenderHints(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        m = 5; r = QRectF(m, m, w-2*m, h-2*m)
        # track
        pen = QPen(QColor(T.BORDER), 5, Qt.SolidLine, Qt.RoundCap); p.setPen(pen)
        p.setBrush(Qt.NoBrush); p.drawArc(r, 225*16, -270*16)
        # arc
        span = int(-270 * self.pct / 100 * 16)
        pen2 = QPen(self.color, 5, Qt.SolidLine, Qt.RoundCap); p.setPen(pen2)
        p.drawArc(r, 225*16, span)
        # glow
        glow_c = QColor(self.color); glow_c.setAlpha(40)
        pen3 = QPen(glow_c, 9, Qt.SolidLine, Qt.RoundCap); p.setPen(pen3)
        p.drawArc(r, 225*16, span)
        # text
        p.setPen(QColor(T.TEXT_PRIMARY))
        p.setFont(QFont(T.FONT_FAMILY, 9, QFont.Bold))
        p.drawText(QRectF(0,0,w,h), Qt.AlignCenter, f"{self.pct}%")


# ── Layout helpers ────────────────────────────────────────────────────────────
def _clear_layout(layout):
    while layout.count():
        item = layout.takeAt(0)
        w = item.widget()
        if w: w.hide(); w.setParent(None); w.deleteLater()
        else:
            lay = item.layout()
            if lay: _clear_layout(lay); lay.deleteLater()


class Panel(QWidget):
    """
    Same decoupling trick as StatCard: the shadow lives on a static,
    childless background frame. `self.body` (and any heavy live content
    added to it, e.g. the keyboard heatmap's 100+ key widgets) sits in a
    separate transparent layer on top, so per-tick updates never force
    Qt to re-rasterize the whole panel through the blur effect.
    """
    def __init__(self, title=None, right_widget=None, parent=None):
        super().__init__(parent)
        grid = QGridLayout(self)
        grid.setContentsMargins(0, 0, 0, 0)

        bg = QFrame()
        bg.setStyleSheet(f"""
            QFrame {{
                background-color:{T.CARD_BG};
                border:1px solid {T.BORDER};
                border-radius:{T.PANEL_RADIUS}px;
            }}
        """)
        soft_shadow(bg)
        grid.addWidget(bg, 0, 0)

        content = QWidget()
        content.setStyleSheet("background: transparent;")
        outer = QVBoxLayout(content)
        outer.setContentsMargins(20, 18, 20, 18); outer.setSpacing(14)
        self.title_label = None
        self.title_row   = QHBoxLayout()
        if title:
            self.title_label = QLabel(title)
            self.title_label.setStyleSheet(
                f"color:{T.TEXT_PRIMARY}; font-size:15px; font-weight:700; background:transparent;"
            )
            self.title_row.addWidget(self.title_label)
            self.title_row.addStretch(1)
            if right_widget:
                self.title_row.addWidget(right_widget)
            outer.addLayout(self.title_row)
        self.body = QVBoxLayout(); self.body.setSpacing(10)
        outer.addLayout(self.body)
        grid.addWidget(content, 0, 0)

    def set_title(self, text):
        if self.title_label: self.title_label.setText(text)

    def clear_body(self):
        _clear_layout(self.body)


def panel_title(text, right_widget=None):
    row = QHBoxLayout()
    lbl = QLabel(text); lbl.setStyleSheet(f"color:{T.TEXT_PRIMARY}; font-size:15px; font-weight:700;")
    row.addWidget(lbl); row.addStretch(1)
    if right_widget: row.addWidget(right_widget)
    return row


def info_row(icon, icon_bg, title, subtitle, right_top, right_bottom="", right_color=None, icon_round=8):
    w = QWidget()
    lay = QHBoxLayout(w); lay.setContentsMargins(0,6,0,6); lay.setSpacing(12)
    ic = QLabel(icon); ic.setFixedSize(32,32); ic.setAlignment(Qt.AlignCenter)
    ic.setStyleSheet(f"background-color:{icon_bg}; border-radius:{icon_round}px; font-size:14px;")
    lay.addWidget(ic)
    mid = QVBoxLayout(); mid.setSpacing(2)
    t = QLabel(title); t.setStyleSheet(f"color:{T.TEXT_PRIMARY}; font-size:13px; font-weight:600;")
    mid.addWidget(t)
    if subtitle:
        s = QLabel(subtitle); s.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:11px;")
        mid.addWidget(s)
    lay.addLayout(mid, 1)
    right = QVBoxLayout(); right.setSpacing(2)
    r1 = QLabel(right_top); r1.setAlignment(Qt.AlignRight)
    r1.setStyleSheet(f"color:{right_color or T.TEXT_PRIMARY}; font-size:12px; font-weight:600;")
    right.addWidget(r1)
    if right_bottom:
        r2 = QLabel(right_bottom); r2.setAlignment(Qt.AlignRight)
        r2.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:11px;")
        right.addWidget(r2)
    lay.addLayout(right)
    return w


def hline():
    f = QFrame(); f.setFixedHeight(1)
    f.setStyleSheet(f"background-color:{T.BORDER_SOFT};")
    return f


def link_label(text):
    l = QLabel(text); l.setStyleSheet(f"color:{T.ACCENT_PURPLE}; font-size:12px; font-weight:600;")
    l.setCursor(Qt.PointingHandCursor); return l


def small_dropdown(text):
    l = QLabel(text + "  ▾")
    l.setStyleSheet(
        f"color:{T.TEXT_SECOND}; font-size:12px; background-color:{T.CARD_BG_2};"
        f"border:1px solid {T.BORDER}; border-radius:8px; padding:6px 10px;"
    )
    return l
