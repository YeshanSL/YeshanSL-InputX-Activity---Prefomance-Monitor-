"""
inputX v2 – Performance Monitoring & Analytics
Smooth UI: all live updates are queued through a 200ms GUI timer so
the worker thread never stalls the paint loop.
"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))

# PERF: pynput installs a system-wide low-level mouse/keyboard hook so it can
# count clicks/keystrokes. Windows requires that hook callback to return
# quickly, or input lags system-wide (not just in this app) while Windows
# waits for it. Because only one thread can run Python at a time (the GIL),
# the hook callback can get starved while the background worker thread is
# doing heavier synchronous work (process scans, psutil calls). Lowering the
# GIL switch interval makes Python hand off control to the hook thread far
# more often, keeping its response time low even under load.
sys.setswitchinterval(0.001)  # default is 0.005s; this favors responsiveness

from PySide6.QtCore    import Qt, QTimer, QEvent
from PySide6.QtGui     import QIcon, QPixmap, QPainter, QColor, QLinearGradient, QFont, QAction
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QHBoxLayout,
                                QVBoxLayout, QStackedWidget, QSystemTrayIcon, QMenu)

from app import theme as T
from app.shell import Sidebar, TopHeader
from app.pages.dashboard   import DashboardPage
from app.pages.mouse       import MousePage
from app.pages.keyboard    import KeyboardPage
from app.pages.controller  import ControllerPage
from app.pages.network     import NetworkPage
from app.pages.games       import GamesPage
from app.pages.settings    import SettingsPage
from app.monitors.system_monitor import SystemMonitor


PAGES = {
    "Dashboard":  DashboardPage,
    "Mouse":      MousePage,
    "Keyboard":   KeyboardPage,
    "Controller": ControllerPage,
    "Network":    NetworkPage,
    "Games":      GamesPage,
    "Settings":   SettingsPage,
}


def _fix_windows_taskbar_icon():
    """
    On Windows, when a GUI app is launched via `python.exe` (e.g. from a
    terminal or VS Code) instead of its own compiled .exe, the taskbar
    groups the window under python.exe's icon by default — the window
    icon set via setWindowIcon() only affects the title bar, not the
    taskbar/grouping icon. Explicitly registering an AppUserModelID tells
    Windows "this is its own app", so it uses our icon in the taskbar too.
    No-op on macOS/Linux.
    """
    if sys.platform != "win32":
        return
    try:
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("InputX.PerformanceMonitor.1")
    except Exception:
        pass


def _logo_path():
    here = os.path.dirname(__file__)
    for p in [os.path.join(here,"inputx_logo.png"),
              os.path.join(here,"app","inputx_logo.png")]:
        if os.path.exists(p): return p
    return None


def _make_icon() -> QIcon:
    lp = _logo_path()
    if lp: return QIcon(lp)
    px = QPixmap(64,64); px.fill(Qt.transparent)
    p  = QPainter(px); p.setRenderHint(QPainter.Antialiasing)
    g  = QLinearGradient(0,0,64,64)
    g.setColorAt(0, QColor("#7c6cf0")); g.setColorAt(1, QColor("#3b82f6"))
    p.setBrush(g); p.setPen(Qt.NoPen); p.drawRoundedRect(0,0,64,64,14,14)
    p.setPen(QColor("white")); p.setFont(QFont("Segoe UI",36,QFont.Black))
    p.drawText(px.rect(), Qt.AlignCenter, "X"); p.end()
    return QIcon(px)


class MainWindow(QMainWindow):
    def __init__(self, monitor: SystemMonitor):
        super().__init__()
        self._monitor = monitor
        self._latest_snap = None      # always the freshest snapshot
        self._really_quit = False

        self.setWindowTitle("inputX – Performance Monitoring & Analytics")
        self.setWindowIcon(_make_icon())
        self.resize(1536, 950); self.setMinimumSize(1100, 700)

        central = QWidget(); self.setCentralWidget(central)
        root = QHBoxLayout(central); root.setContentsMargins(0,0,0,0); root.setSpacing(0)

        self.sidebar = Sidebar()
        self.sidebar.page_changed.connect(self.show_page)
        root.addWidget(self.sidebar)

        right = QWidget()
        rl = QVBoxLayout(right); rl.setContentsMargins(28,24,28,20); rl.setSpacing(20)
        self.header = TopHeader(); rl.addWidget(self.header)
        self.stack  = QStackedWidget(); rl.addWidget(self.stack, 1)
        root.addWidget(right, 1)

        self._page_instances = {}
        for name in PAGES: self._get_page(name)
        self.show_page("Dashboard")

        # Worker → store latest snapshot (non-blocking)
        monitor.updated.connect(self._store_snapshot)

        # GUI dispatch timer: 250ms – smooth without overloading paint
        self._gui_timer = QTimer(self)
        self._gui_timer.setInterval(250)
        self._gui_timer.timeout.connect(self._flush_snapshot)
        self._gui_timer.start()

    def _get_page(self, name):
        if name not in self._page_instances:
            page = PAGES[name]()
            self._page_instances[name] = page
            self.stack.addWidget(page)
        return self._page_instances[name]

    def show_page(self, name):
        page = self._get_page(name)
        self.stack.setCurrentWidget(page)
        if getattr(page, "has_own_header", False):
            self.header.hide()
        else:
            self.header.show()
            self.header.set_titles(page.title, page.subtitle)

    def _store_snapshot(self, snap: dict):
        """Called from worker thread via queued connection – just store it."""
        self._latest_snap = snap

    def _flush_snapshot(self):
        """Called every 250ms on GUI thread – dispatches to visible pages."""
        snap = self._latest_snap
        if snap is None:
            return

        # Always update header + sidebar (cheap label sets)
        self.header.update_datetime(snap)

        # Dispatch only to the currently visible page for max smoothness
        # Background pages are updated when you switch to them
        current = self.stack.currentWidget()
        fn = getattr(current, "on_snapshot", None)
        if callable(fn):
            try: fn(snap)
            except Exception as e:
                print(f"[dispatch] {current.__class__.__name__}: {e}")

    def changeEvent(self, ev):
        if ev.type() == QEvent.WindowStateChange and self.isMinimized():
            QTimer.singleShot(100, self.hide)
        super().changeEvent(ev)

    def closeEvent(self, ev):
        if self._really_quit:
            self._gui_timer.stop(); self._monitor.stop(); ev.accept()
        else:
            self.hide(); ev.ignore()


class TrayManager:
    def __init__(self, app, window):
        self._app = app; self._window = window
        self._tray = QSystemTrayIcon(_make_icon(), app)
        self._tray.setToolTip("inputX – Performance Monitoring & Analytics")

        menu = QMenu()
        menu.setStyleSheet(f"""
            QMenu {{ background:#111623; color:#f3f5f9; border:1px solid #1e2433;
                     border-radius:8px; padding:6px; font-size:13px; }}
            QMenu::item {{ padding:8px 20px; border-radius:6px; }}
            QMenu::item:selected {{ background:{T.ACCENT_PURPLE}; }}
            QMenu::separator {{ height:1px; background:#1e2433; margin:4px 10px; }}
        """)

        def act(label, fn):
            a = QAction(label, menu); a.triggered.connect(fn); menu.addAction(a); return a

        act("🖥  Open inputX",   self._show)
        menu.addSeparator()
        act("▦  Dashboard",      lambda: self._goto("Dashboard"))
        act("🖱  Mouse",          lambda: self._goto("Mouse"))
        act("⌨  Keyboard",        lambda: self._goto("Keyboard"))
        act("🌐  Network",        lambda: self._goto("Network"))
        act("🎮  Games",          lambda: self._goto("Games"))
        act("⚙  Settings",        lambda: self._goto("Settings"))
        menu.addSeparator()
        act("✕  Quit inputX",     self._quit)

        self._tray.setContextMenu(menu)
        self._tray.activated.connect(self._on_activated)
        self._tray.show()
        self._tray.showMessage("inputX","Monitoring in background.",QSystemTrayIcon.Information,3000)

    def _show(self):
        self._window.showNormal(); self._window.activateWindow(); self._window.raise_()

    def _goto(self, page):
        self._show(); self._window.show_page(page)
        self._window.sidebar._select(page)

    def _on_activated(self, reason):
        if reason == QSystemTrayIcon.DoubleClick: self._show()
        elif reason == QSystemTrayIcon.Trigger:
            self._show() if not self._window.isVisible() else self._window.hide()

    def _quit(self):
        self._window._really_quit = True
        self._tray.hide(); self._app.quit()


def main():
    _fix_windows_taskbar_icon()

    app = QApplication(sys.argv)
    app.setApplicationName("inputX"); app.setOrganizationName("InputX")
    app.setWindowIcon(_make_icon()); app.setQuitOnLastWindowClosed(False)
    app.setStyleSheet(T.build_qss())

    monitor = SystemMonitor(); monitor.start()
    win  = MainWindow(monitor)
    win.setStyleSheet(f"QMainWindow {{ background:{T.BG}; }}")
    win.show()

    tray = TrayManager(app, win)  # keep alive
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
