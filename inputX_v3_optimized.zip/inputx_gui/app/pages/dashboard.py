"""
Dashboard – accurate live system overview.
Updates every second; only repaints widgets whose data changed.
"""
from PySide6.QtCore    import Qt
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                                QScrollArea, QSizePolicy, QFrame)

from .. import theme as T
from ..widgets import (StatCard, MultiLineChart, ChartLegend, Panel,
                        CircularGauge, link_label, small_dropdown, info_row)


def scrollable(content_widget):
    sa = QScrollArea()
    sa.setWidgetResizable(True)
    sa.setWidget(content_widget)
    sa.setFrameShape(QScrollArea.NoFrame)
    sa.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
    return sa


class DashboardPage(QWidget):
    title    = "Dashboard"
    subtitle = "Live system performance overview"

    def __init__(self, parent=None):
        super().__init__(parent)
        outer = QVBoxLayout(self); outer.setContentsMargins(0,0,0,0)

        body = QWidget()
        lay  = QVBoxLayout(body)
        lay.setContentsMargins(4,4,4,4); lay.setSpacing(18)

        # ── Top stat cards ────────────────────────────────────────────────
        stats = QHBoxLayout(); stats.setSpacing(14)
        self._c_cpu  = StatCard("🖥", T.ACCENT_PURPLE, "CPU Usage",    "—%",   "Live",   [0]*12)
        self._c_ram  = StatCard("💾", T.ACCENT_BLUE,   "RAM Usage",    "—%",   "Live",   [0]*12)
        self._c_disk = StatCard("💿", T.ACCENT_TEAL,   "Disk Read",    "— MB/s","I/O",   [0]*12)
        self._c_dl   = StatCard("↓",  "#14c8a6",       "Download",     "—",    "Mbps",   [0]*12)
        self._c_ul   = StatCard("↑",  T.ACCENT_PINK,   "Upload",       "—",    "Mbps",   [0]*12)
        for c in (self._c_cpu, self._c_ram, self._c_disk, self._c_dl, self._c_ul):
            stats.addWidget(c)
        lay.addLayout(stats)

        # ── Middle: rolling chart + system gauges ─────────────────────────
        mid = QHBoxLayout(); mid.setSpacing(18)

        chart_p = Panel("Activity Timeline", small_dropdown("60 s"))
        chart_p.body.addWidget(ChartLegend([
            ("CPU %",   T.ACCENT_PURPLE),
            ("RAM %",   T.ACCENT_BLUE),
            ("DL Mbps", "#14c8a6"),
        ]))
        self._chart = MultiLineChart(
            [{"name":"CPU %", "color":T.ACCENT_PURPLE,"data":[0]*60},
             {"name":"RAM %", "color":T.ACCENT_BLUE,  "data":[0]*60},
             {"name":"DL",    "color":"#14c8a6",       "data":[0]*60}],
            [], y_max=100)
        chart_p.body.addWidget(self._chart)
        mid.addWidget(chart_p, 3)

        # Gauges panel
        gauge_p = Panel("System Status")
        self._gauges = {}
        for key, label, color in [
            ("cpu",  "CPU Usage",  T.ACCENT_PURPLE),
            ("ram",  "RAM Usage",  T.ACCENT_BLUE),
            ("disk", "Disk Usage", T.ACCENT_TEAL),
            ("gpu",  "GPU Usage",  T.ACCENT_PINK),
        ]:
            row = QHBoxLayout(); row.setSpacing(12)
            g   = CircularGauge(0, color)
            row.addWidget(g)
            col = QVBoxLayout(); col.setSpacing(2)
            tl  = QLabel(label)
            tl.setStyleSheet(f"color:{T.TEXT_PRIMARY}; font-size:12px; font-weight:600;")
            sl  = QLabel("—")
            sl.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:10px;")
            col.addWidget(tl); col.addWidget(sl)
            row.addLayout(col, 1)
            gauge_p.body.addLayout(row)
            self._gauges[key] = (g, sl)
        gauge_p.body.addStretch(1)
        mid.addWidget(gauge_p, 1)
        lay.addLayout(mid)

        # ── Bottom: top processes + detail metrics ────────────────────────
        bot = QHBoxLayout(); bot.setSpacing(18)

        # Top processes
        proc_p = Panel("Top Processes by CPU")
        hdr = QHBoxLayout()
        for txt, w in [("Process",0),("CPU%",52),("RAM%",52)]:
            l = QLabel(txt); l.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:10px; font-weight:600;")
            if w: l.setFixedWidth(w); l.setAlignment(Qt.AlignRight)
            hdr.addWidget(l, 0 if w else 1)
        proc_p.body.addLayout(hdr)
        self._proc_rows = []
        for _ in range(10):
            row = QHBoxLayout()
            nm  = QLabel("—"); nm.setStyleSheet(f"color:{T.TEXT_PRIMARY}; font-size:11px;")
            cpu = QLabel("—"); cpu.setFixedWidth(52); cpu.setAlignment(Qt.AlignRight)
            cpu.setStyleSheet(f"color:{T.ACCENT_PURPLE}; font-size:11px; font-weight:600;")
            mem = QLabel("—"); mem.setFixedWidth(52); mem.setAlignment(Qt.AlignRight)
            mem.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:11px;")
            row.addWidget(nm,1); row.addWidget(cpu); row.addWidget(mem)
            proc_p.body.addLayout(row)
            self._proc_rows.append((nm,cpu,mem))
        proc_p.body.addStretch(1)
        bot.addWidget(proc_p, 1)

        # Quick metrics panel
        met_p = Panel("System Details")
        self._met_vals = {}
        for key, label, color in [
            ("cpu_freq",  "CPU Frequency",  T.TEXT_PRIMARY),
            ("cpu_cores", "CPU Cores",      T.TEXT_PRIMARY),
            ("ram_avail", "RAM Available",  T.ACCENT_TEAL),
            ("disk_rw",   "Disk Read/Write",T.ACCENT_BLUE),
            ("net_ip",    "Local IP",       T.TEXT_SECOND),
            ("gpu_name",  "GPU",            T.ACCENT_PINK),
            ("uptime",    "Session Uptime", T.ACCENT_PURPLE),
        ]:
            row = QHBoxLayout()
            l = QLabel(label); l.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:11px;")
            v = QLabel("—"); v.setAlignment(Qt.AlignRight)
            v.setStyleSheet(f"color:{color}; font-size:11px; font-weight:600;")
            v.setWordWrap(True)
            row.addWidget(l); row.addStretch(1); row.addWidget(v)
            met_p.body.addLayout(row)
            self._met_vals[key] = v

        # Divider
        sep = QFrame(); sep.setFixedHeight(1)
        sep.setStyleSheet(f"background:{T.BORDER_SOFT};")
        met_p.body.addWidget(sep)

        # Network quick view
        net_lbl = QLabel("Network")
        net_lbl.setStyleSheet(f"color:{T.TEXT_PRIMARY}; font-size:12px; font-weight:600;")
        met_p.body.addWidget(net_lbl)
        self._net_vals = {}
        for key, label, color in [
            ("dl",   "↓ Download",  "#14c8a6"),
            ("ul",   "↑ Upload",    T.ACCENT_PURPLE),
            ("ping", "⟳ Ping",      T.ACCENT_BLUE),
        ]:
            row = QHBoxLayout()
            l = QLabel(label); l.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:11px;")
            v = QLabel("—"); v.setAlignment(Qt.AlignRight)
            v.setStyleSheet(f"color:{color}; font-size:12px; font-weight:700;")
            row.addWidget(l); row.addStretch(1); row.addWidget(v)
            met_p.body.addLayout(row)
            self._net_vals[key] = v
        met_p.body.addStretch(1)
        bot.addWidget(met_p, 1)
        lay.addLayout(bot)

        lay.addStretch(1)
        outer.addWidget(scrollable(body))

    def on_snapshot(self, snap: dict):
        cpu = snap["cpu_pct"]; ram = snap["ram_pct"]
        dl  = snap["dl_mbps"]; ul  = snap["ul_mbps"]
        disk_r = snap["disk_r_mb"]; disk_w = snap["disk_w_mb"]

        # Stat cards
        self._c_cpu.update_live( f"{cpu:.1f}%",     "CPU",    snap["cpu_hist"][-12:])
        self._c_ram.update_live( f"{ram:.1f}%",     "RAM",    snap["ram_hist"][-12:])
        self._c_disk.update_live(f"{disk_r:.1f} MB/s","Read", snap["disk_r_hist"][-12:])
        self._c_dl.update_live(  f"{dl:.1f} Mbps",  "DL",    snap["dl_hist"][-12:])
        self._c_ul.update_live(  f"{ul:.1f} Mbps",  "UL",    snap["ul_hist"][-12:])

        # Chart – scale download to 0-100 axis so it's visible
        dl_hist_scaled = [min(v*5, 100) for v in snap["dl_hist"]]
        self._chart.update_series([
            {"name":"CPU %","color":T.ACCENT_PURPLE,"data":snap["cpu_hist"]},
            {"name":"RAM %","color":T.ACCENT_BLUE,  "data":snap["ram_hist"]},
            {"name":"DL",   "color":"#14c8a6",       "data":dl_hist_scaled},
        ])

        # Gauges
        g_cpu, s_cpu = self._gauges["cpu"]
        g_cpu.update_pct(int(cpu))
        s_cpu.setText(snap.get("cpu_freq","—"))

        g_ram, s_ram = self._gauges["ram"]
        g_ram.update_pct(int(ram))
        s_ram.setText(f"{snap['ram_used']} / {snap['ram_total']} GB")

        g_disk, s_disk = self._gauges["disk"]
        g_disk.update_pct(int(snap["disk_pct"]))
        s_disk.setText(f"{snap['disk_used']} / {snap['disk_total']} GB")

        g_gpu, s_gpu = self._gauges["gpu"]
        g_gpu.update_pct(snap["gpu_pct"])
        s_gpu.setText(snap["gpu_name"])

        # Top processes
        for i, (nm, cpu_l, mem_l) in enumerate(self._proc_rows):
            if i < len(snap["top_procs"]):
                n, c, m = snap["top_procs"][i]
                nm.setText(n[:30]); cpu_l.setText(f"{c:.1f}%"); mem_l.setText(f"{m:.1f}%")
            else:
                nm.setText("—"); cpu_l.setText("—"); mem_l.setText("—")

        # Detail metrics
        mv = self._met_vals
        mv["cpu_freq"].setText(snap.get("cpu_freq","—"))
        mv["cpu_cores"].setText(f"{snap.get('cpu_logic','—')} logical / {snap.get('cpu_cores','—')} physical")
        mv["ram_avail"].setText(f"{snap['ram_avail']} GB free")
        mv["disk_rw"].setText(f"R:{disk_r:.1f}  W:{disk_w:.1f} MB/s")
        mv["net_ip"].setText(snap.get("net_ip","—"))
        mv["gpu_name"].setText(snap["gpu_name"][:28])
        mv["uptime"].setText(snap["uptime"])

        # Network quick
        self._net_vals["dl"].setText(f"{dl:.2f} Mbps")
        self._net_vals["ul"].setText(f"{ul:.2f} Mbps")
        self._net_vals["ping"].setText(f"{snap['ping_ms']} ms")

        # Sidebar uptime
        try:
            mw = self.window()
            if hasattr(mw, "sidebar"):
                mw.sidebar.update_uptime(snap["uptime"])
        except Exception:
            pass
