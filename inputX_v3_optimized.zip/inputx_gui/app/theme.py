"""
Central theme / design tokens for the inputX dashboard clone.
Keep every color & metric here so all pages stay visually consistent.
"""

# ---- Core palette -----------------------------------------------------
BG            = "#0a0e16"   # app background
SIDEBAR_BG    = "#0c1019"   # sidebar background
CARD_BG       = "#111623"   # card / panel background
CARD_BG_2     = "#0f141f"   # slightly darker nested panel
BORDER        = "#1e2433"   # card borders
BORDER_SOFT   = "#171c29"

TEXT_PRIMARY  = "#f3f5f9"
TEXT_SECOND   = "#8b93a7"
TEXT_MUTED    = "#5b6479"

ACCENT_PURPLE = "#7c6cf0"
ACCENT_PURPLE2= "#5b6cf0"
ACCENT_BLUE   = "#3b82f6"
ACCENT_TEAL   = "#14c8a6"
ACCENT_ORANGE = "#f5a623"
ACCENT_PINK   = "#ef4d77"
ACCENT_GREEN  = "#22c55e"
ACCENT_RED    = "#ef4444"
ACCENT_CYAN   = "#22d3ee"

UP_COLOR      = "#3ddc84"
DOWN_COLOR    = "#ef4444"

SIDEBAR_ACTIVE_GRAD = ("#6f5cf6", "#4f6cf3")

FONT_FAMILY = "Segoe UI"

CARD_RADIUS = 14
PANEL_RADIUS = 16

# ---- Global stylesheet -------------------------------------------------
def build_qss():
    return f"""
    QWidget {{
        background-color: transparent;
        color: {TEXT_PRIMARY};
        font-family: '{FONT_FAMILY}';
    }}
    QMainWindow {{
        background-color: {BG};
    }}
    QScrollArea {{
        border: none;
        background: transparent;
    }}
    QScrollArea > QWidget > QWidget {{
        background: transparent;
    }}
    QScrollBar:vertical {{
        background: transparent;
        width: 8px;
        margin: 4px;
    }}
    QScrollBar::handle:vertical {{
        background: #2a3142;
        border-radius: 4px;
        min-height: 24px;
    }}
    QScrollBar::handle:vertical:hover {{
        background: #3a4258;
    }}
    QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
        height: 0px;
    }}
    QScrollBar:horizontal {{ height: 0px; }}

    QPushButton {{
        border: none;
        outline: none;
    }}
    QLabel {{
        background: transparent;
    }}
    QToolTip {{
        background-color: {CARD_BG};
        color: {TEXT_PRIMARY};
        border: 1px solid {BORDER};
        padding: 6px;
        border-radius: 6px;
    }}
    QComboBox {{
        background-color: {CARD_BG_2};
        border: 1px solid {BORDER};
        border-radius: 8px;
        padding: 6px 10px;
        color: {TEXT_SECOND};
        font-size: 12px;
    }}
    QComboBox::drop-down {{
        border: none;
        width: 20px;
    }}
    QComboBox QAbstractItemView {{
        background-color: {CARD_BG};
        color: {TEXT_PRIMARY};
        border: 1px solid {BORDER};
        selection-background-color: {ACCENT_PURPLE};
    }}
    """
