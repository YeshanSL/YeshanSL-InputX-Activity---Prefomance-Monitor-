"""Mouse page – live click/scroll counters + heatmap."""
from PySide6.QtCore    import Qt
from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame

from .. import theme as T
from ..widgets import (StatCard, MultiLineChart, ChartLegend, Panel, DonutChart,
                        HeatmapWidget, HeatmapLegendBar, link_label, small_dropdown)
from .dashboard import scrollable


def device_badge(name, status="Connected", icon_char="🖱"):
    f = QFrame()
    f.setStyleSheet(
        f"background-color:{T.CARD_BG}; border:1px solid {T.BORDER}; border-radius:12px;"
    )
    lay = QHBoxLayout(f); lay.setContentsMargins(14, 10, 16, 10); lay.setSpacing(10)
    icon = QLabel(icon_char)
    icon.setFixedSize(34, 34); icon.setAlignment(Qt.AlignCenter)
    icon.setStyleSheet(
        f"background-color:{T.CARD_BG_2}; border-radius:8px; font-size:15px;"
    )
    lay.addWidget(icon)
    col = QVBoxLayout(); col.setSpacing(2)
    n = QLabel(name); n.setStyleSheet(f"color:{T.TEXT_PRIMARY}; font-size:12px; font-weight:600;")
    s = QHBoxLayout()
    dot = QLabel("●"); dot.setStyleSheet(f"color:{T.ACCENT_GREEN}; font-size:8px;")
    st  = QLabel(status); st.setStyleSheet(f"color:{T.ACCENT_GREEN}; font-size:10px;")
    s.addWidget(dot); s.addWidget(st); s.addStretch(1)
    col.addWidget(n); col.addLayout(s)
    lay.addLayout(col)
    return f


def page_header(title, subtitle, device_name, device_kind, icon_char="🖱"):
    row = QHBoxLayout()
    left = QVBoxLayout(); left.setSpacing(4)
    t = QLabel(title); t.setStyleSheet("color:white; font-size:24px; font-weight:700;")
    s = QLabel(subtitle); s.setStyleSheet(f"color:{T.TEXT_SECOND}; font-size:13px;")
    left.addWidget(t); left.addWidget(s)
    row.addLayout(left); row.addStretch(1)
    row.addWidget(device_badge(device_name, device_kind, icon_char))
    refresh = QLabel("⟳  Live")
    refresh.setStyleSheet(
        f"color:{T.ACCENT_GREEN}; font-size:12px; background-color:{T.CARD_BG}; "
        f"border:1px solid {T.BORDER}; border-radius:10px; padding:10px 14px;"
    )
    row.addWidget(refresh)
    return row


class MousePage(QWidget):
    title    = "Mouse"
    subtitle = "Detailed mouse activity and performance analytics"
    has_own_header = True

    def __init__(self, parent=None):
        super().__init__(parent)
        outer = QVBoxLayout(self); outer.setContentsMargins(0, 0, 0, 0)
        body  = QWidget()
        lay   = QVBoxLayout(body); lay.setContentsMargins(4, 4, 4, 4); lay.setSpacing(18)

        lay.addLayout(page_header(self.title, self.subtitle,
                                  "Mouse (tracking)", "Connected", "🖱"))

        # Stat cards
        stats = QHBoxLayout(); stats.setSpacing(18)
        self._card_total   = StatCard("🖱", T.ACCENT_PURPLE, "Total Clicks",   "0",  "Session", [0]*12)
        self._card_scroll  = StatCard("◷", T.ACCENT_ORANGE, "Scrolls",        "0",  "Session", [0]*12)
        self._card_cps     = StatCard("⚡", T.ACCENT_TEAL,   "Clicks / sec",   "0",  "Live",    [0]*12)
        self._card_dist    = StatCard("✳", T.ACCENT_BLUE,   "Distance (m)",   "0",  "Session", [0]*12)
        self._card_pynput  = StatCard("🔌", T.ACCENT_PINK,   "Input Tracking", "—",  "—",       [6]*12)
        for c in (self._card_total, self._card_scroll, self._card_cps,
                  self._card_dist, self._card_pynput):
            stats.addWidget(c)
        lay.addLayout(stats)

        # Live CPS chart
        mid = QHBoxLayout(); mid.setSpacing(18)
        chart_panel = Panel("Clicks Per Second (Live)", small_dropdown("Last 60 s"))
        chart_panel.body.addWidget(ChartLegend([("Clicks/s", T.ACCENT_PURPLE)]))
        self._chart = MultiLineChart(
            [{"name": "CPS", "color": T.ACCENT_PURPLE, "data": [0]*60}],
            [], y_max=10)
        chart_panel.body.addWidget(self._chart)
        mid.addWidget(chart_panel, 2)

        # Click distribution donut (static visual for now)
        donut_panel = Panel("Click Distribution")
        donut_row = QHBoxLayout()
        donut_row.addWidget(DonutChart(
            [70, 24, 6],
            [T.ACCENT_PURPLE, T.ACCENT_BLUE, T.ACCENT_TEAL],
            "Types", "Left\nRight\nMiddle"
        ))
        legend_col = QVBoxLayout()
        for label, pct, color in [("Left Clicks",   "~70%", T.ACCENT_PURPLE),
                                   ("Right Clicks",  "~24%", T.ACCENT_BLUE),
                                   ("Middle Clicks", "~6%",  T.ACCENT_TEAL)]:
            r = QHBoxLayout()
            dot = QLabel(); dot.setFixedSize(9, 9)
            dot.setStyleSheet(f"background-color:{color}; border-radius:5px;")
            r.addWidget(dot)
            txt = QVBoxLayout(); txt.setSpacing(0)
            l1 = QLabel(label); l1.setStyleSheet(f"color:{T.TEXT_PRIMARY}; font-size:12px; font-weight:600;")
            l2 = QLabel(pct); l2.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:11px;")
            txt.addWidget(l1); txt.addWidget(l2); r.addLayout(txt); r.addStretch(1)
            legend_col.addLayout(r)
        donut_row.addLayout(legend_col, 1)
        donut_panel.body.addLayout(donut_row)
        donut_panel.body.addStretch(1)
        mid.addWidget(donut_panel, 1)
        lay.addLayout(mid)

        # Heatmap
        bottom2 = QHBoxLayout(); bottom2.setSpacing(18)
        heat_panel = Panel("Mouse Heatmap (Session)", small_dropdown("Screen 1"))
        heat_panel.body.addWidget(HeatmapWidget())
        legend_row = QHBoxLayout()
        lo = QLabel("Low"); lo.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:11px;")
        hi = QLabel("High"); hi.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:11px;")
        legend_row.addWidget(lo)
        legend_row.addWidget(HeatmapLegendBar(), 1)
        legend_row.addWidget(hi)
        heat_panel.body.addLayout(legend_row)
        bottom2.addWidget(heat_panel, 2)

        tip_panel = Panel("Tracking Info")
        info_lbl = QLabel(
            "Real mouse click tracking requires the pynput library.\n\n"
            "Install with:\n  pip install pynput\n\n"
            "Then restart inputX to enable live click counting."
        )
        info_lbl.setStyleSheet(f"color:{T.TEXT_SECOND}; font-size:12px;")
        info_lbl.setWordWrap(True)
        tip_panel.body.addWidget(info_lbl)
        tip_panel.body.addStretch(1)
        bottom2.addWidget(tip_panel, 1)
        lay.addLayout(bottom2)

        lay.addStretch(1)
        outer.addWidget(scrollable(body))

        self._total_dist = 0.0

    def on_snapshot(self, snap: dict):
        total = snap["mouse_clicks"]
        delta = snap["mouse_delta"]
        scroll = snap["scroll_total"]
        ok    = snap["pynput_ok"]
        self._total_dist += snap.get("mouse_dist_m", 0)

        self._card_total.update_live(str(total),          "total clicks",   snap["mouse_hist"][-12:])
        self._card_scroll.update_live(str(scroll),        "total scrolls",  [0]*12)
        self._card_cps.update_live(f"{delta}",            "clicks/s",       snap["mouse_hist"][-12:])
        self._card_dist.update_live(f"{self._total_dist:.2f} m",
                                    "distance",           [0]*12)
        self._card_pynput.update_live(
            "Active" if ok else "No pynput",
            "click tracking",
            [6]*12
        )

        self._chart.update_series([
            {"name": "CPS", "color": T.ACCENT_PURPLE, "data": snap["mouse_hist"]}
        ])
