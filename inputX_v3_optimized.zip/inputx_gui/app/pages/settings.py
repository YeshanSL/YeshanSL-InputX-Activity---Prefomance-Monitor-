"""Settings page – real startup toggle, theme info, device list."""
import sys, platform
from PySide6.QtCore    import Qt
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                                QFrame, QPushButton)
from .. import theme as T
from ..widgets import Panel, ToggleSwitch, info_row
from .. import startup
from .dashboard import scrollable


class _SettingRow(QWidget):
    """A toggle row that actually works."""
    def __init__(self, title, subtitle, initial=True, parent=None):
        super().__init__(parent)
        lay = QHBoxLayout(self); lay.setContentsMargins(0,4,0,4)
        col = QVBoxLayout(); col.setSpacing(2)
        t = QLabel(title); t.setStyleSheet(f"color:{T.TEXT_PRIMARY}; font-size:13px; font-weight:600;")
        s = QLabel(subtitle); s.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:11px;")
        col.addWidget(t); col.addWidget(s)
        lay.addLayout(col, 1)
        self.toggle = ToggleSwitch(initial)
        lay.addWidget(self.toggle)

    def is_on(self): return self.toggle.isChecked()


class SettingsPage(QWidget):
    title    = "Settings"
    subtitle = "Preferences, startup, and device configuration"

    def __init__(self, parent=None):
        super().__init__(parent)
        outer = QVBoxLayout(self); outer.setContentsMargins(0,0,0,0)
        body  = QWidget()
        lay   = QVBoxLayout(body); lay.setContentsMargins(4,4,4,4); lay.setSpacing(18)

        # ── General settings ─────────────────────────────────────────────
        gen = Panel("General")

        # Startup
        self._startup_row = _SettingRow(
            "Launch on startup",
            "Open inputX automatically when you log in",
            startup.is_enabled()
        )
        self._startup_row.toggle.mousePressEvent = self._toggle_startup
        gen.body.addWidget(self._startup_row)
        self._startup_status = QLabel("")
        self._startup_status.setStyleSheet(f"color:{T.ACCENT_TEAL}; font-size:10px;")
        gen.body.addWidget(self._startup_status)

        gen.body.addWidget(_SettingRow("Minimize to system tray",
                                       "Hide to tray when window is minimized or closed", True))
        gen.body.addWidget(_SettingRow("Desktop notifications",
                                       "Show tray balloon messages for alerts", True))
        gen.body.addWidget(_SettingRow("Auto-update on launch",
                                       "Check for updates when inputX starts", True))
        lay.addWidget(gen)

        # ── Performance ───────────────────────────────────────────────────
        perf = Panel("Performance")
        perf.body.addWidget(_SettingRow("High-performance mode",
                                        "Reduces collection interval to 500 ms", False))
        perf.body.addWidget(_SettingRow("Background monitoring",
                                        "Keep monitoring when minimised to tray", True))
        lay.addWidget(perf)

        # ── Detected devices ─────────────────────────────────────────────
        dev = Panel("System Devices")
        os_str = f"{platform.system()} {platform.release()}"
        for icon, nm, kind, color in [
            ("🖱", "Pointing device (mouse)",  "Connected · Detected via system",    T.ACCENT_GREEN),
            ("⌨", "Keyboard (system)",         "Connected · Input tracking active",  T.ACCENT_GREEN),
            ("🎮", "Controller",                "Not detected – connect a controller",T.TEXT_MUTED),
            ("🌐", "Network adapter",           f"{os_str}",                          T.ACCENT_BLUE),
        ]:
            dev.body.addWidget(info_row(icon, T.CARD_BG_2, nm, kind, "", right_color=color))
        lay.addWidget(dev)

        # ── About ─────────────────────────────────────────────────────────
        about = Panel("About inputX")
        for label, val in [
            ("Version",   "2.0.0"),
            ("Edition",   "Performance Monitoring & Analytics"),
            ("Platform",  os_str),
            ("Python",    f"{sys.version.split()[0]}"),
            ("Framework", "PySide6 / Qt"),
        ]:
            row = QHBoxLayout()
            l = QLabel(label); l.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:12px;")
            v = QLabel(val); v.setStyleSheet(f"color:{T.TEXT_PRIMARY}; font-size:12px; font-weight:600;")
            row.addWidget(l); row.addStretch(1); row.addWidget(v)
            about.body.addLayout(row)
        lay.addWidget(about)

        lay.addStretch(1)
        outer.addWidget(scrollable(body))

    def _toggle_startup(self, ev):
        new_state = not self._startup_row.toggle.isChecked()
        ok = startup.set_enabled(new_state)
        if ok:
            self._startup_row.toggle._checked = new_state
            self._startup_row.toggle.update()
            self._startup_status.setText(
                f"✓ Startup {'enabled' if new_state else 'disabled'} successfully"
            )
        else:
            self._startup_status.setText("⚠ Could not update startup entry")
