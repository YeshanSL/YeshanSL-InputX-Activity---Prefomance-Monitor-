"""
Keyboard page – fully featured live heatmap.

Features:
  • Live per-key percentage labels drawn inside each key
  • 5 colour schemes: Purple Glow, Fire, Ice, Matrix, Mono
  • Toggle: show/hide percentage labels
  • Brightness slider (dim → vivid)
  • Top-10 table with share bars
  • Key category donut
  • Demo data when pynput not installed
  • Dirty-flag repaint (only changed keys redraw)
"""
import math
from PySide6.QtCore    import Qt, QRectF, QPointF
from PySide6.QtGui     import (QPainter, QColor, QFont, QPainterPath,
                                QLinearGradient, QPen)
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                                QFrame, QSizePolicy, QScrollArea, QSlider,
                                QButtonGroup, QPushButton, QComboBox)

from .. import theme as T
from ..widgets import StatCard, MultiLineChart, Panel, DonutChart, small_dropdown
from .dashboard import scrollable
from .mouse import page_header

UNIT = 42   # pixels per 1-unit key

# ── Key layout ────────────────────────────────────────────────────────────────
MAIN_ROWS = [
    [("ESC",1,"ESCAPE"),("",0.5,None),
     ("F1",1,"F1"),("F2",1,"F2"),("F3",1,"F3"),("F4",1,"F4"),("",0.3,None),
     ("F5",1,"F5"),("F6",1,"F6"),("F7",1,"F7"),("F8",1,"F8"),("",0.3,None),
     ("F9",1,"F9"),("F10",1,"F10"),("F11",1,"F11"),("F12",1,"F12")],
    [("`",1,"`"),("1",1,"1"),("2",1,"2"),("3",1,"3"),("4",1,"4"),("5",1,"5"),
     ("6",1,"6"),("7",1,"7"),("8",1,"8"),("9",1,"9"),("0",1,"0"),("-",1,"-"),
     ("=",1,"="),("⌫",2,"BACKSPACE")],
    [("TAB",1.5,"TAB"),("Q",1,"Q"),("W",1,"W"),("E",1,"E"),("R",1,"R"),("T",1,"T"),
     ("Y",1,"Y"),("U",1,"U"),("I",1,"I"),("O",1,"O"),("P",1,"P"),("[",1,"["),
     ("]",1,"]"),("\\",1.5,"\\")],
    [("CAPS",1.75,"CAPS_LOCK"),("A",1,"A"),("S",1,"S"),("D",1,"D"),("F",1,"F"),
     ("G",1,"G"),("H",1,"H"),("J",1,"J"),("K",1,"K"),("L",1,"L"),(";",1,";"),
     ("'",1,"'"),("↵",2.25,"ENTER")],
    [("⇧",2.25,"SHIFT"),("Z",1,"Z"),("X",1,"X"),("C",1,"C"),("V",1,"V"),
     ("B",1,"B"),("N",1,"N"),("M",1,"M"),(",",1,","),(". ",1,"."),("/",1,"/"),
     ("⇧",2.75,"SHIFT")],
    [("CTRL",1.25,"CTRL"),("⊞",1.25,"CMD"),("ALT",1.25,"ALT"),
     ("SPACE",6.25,"SPACE"),("ALT",1.25,"ALT"),("⊞",1.25,"CMD"),
     ("▤",1.25,"MENU"),("CTRL",1.25,"CTRL")],
]
NAV_ROWS = [
    [("PRT",1,"PRINT_SCREEN"),("SLK",1,"SCROLL_LOCK"),("BRK",1,"PAUSE")],
    [],
    [("INS",1,"INSERT"),("HOM",1,"HOME"),("PU",1,"PAGE_UP")],
    [("DEL",1,"DELETE"),("END",1,"END"),("PD",1,"PAGE_DOWN")],
    [("",1,None),("▲",1,"UP"),("",1,None)],
    [("◀",1,"LEFT"),("▼",1,"DOWN"),("▶",1,"RIGHT")],
]
NUMPAD_ROWS = [
    [],
    [("NL",1,"NUM_LOCK"),("/",1,"NUM_DIVIDE"),("*",1,"NUM_MULTIPLY"),("-",1,"NUM_SUBTRACT")],
    [("7",1,"NUM_7"),("8",1,"NUM_8"),("9",1,"NUM_9"),("+",1,"NUM_ADD")],
    [("4",1,"NUM_4"),("5",1,"NUM_5"),("6",1,"NUM_6"),("",0,None)],
    [("1",1,"NUM_1"),("2",1,"NUM_2"),("3",1,"NUM_3"),("↵",1,"NUM_ENTER")],
    [("0",2,"NUM_0"),(".",1,"NUM_DECIMAL"),("↵",1,"NUM_ENTER")],
]

PYNPUT_MAP = {
    "space":"SPACE","enter":"ENTER","backspace":"BACKSPACE","tab":"TAB",
    "shift":"SHIFT","shift_r":"SHIFT","shift_l":"SHIFT",
    "ctrl":"CTRL","ctrl_r":"CTRL","ctrl_l":"CTRL",
    "alt":"ALT","alt_r":"ALT","alt_l":"ALT",
    "cmd":"CMD","cmd_r":"CMD","cmd_l":"CMD",
    "caps_lock":"CAPS_LOCK","up":"UP","down":"DOWN","left":"LEFT","right":"RIGHT",
    "f1":"F1","f2":"F2","f3":"F3","f4":"F4","f5":"F5","f6":"F6",
    "f7":"F7","f8":"F8","f9":"F9","f10":"F10","f11":"F11","f12":"F12",
    "delete":"DELETE","insert":"INSERT","home":"HOME","end":"END",
    "page_up":"PAGE_UP","page_down":"PAGE_DOWN","print_screen":"PRINT_SCREEN",
    "scroll_lock":"SCROLL_LOCK","pause":"PAUSE","num_lock":"NUM_LOCK",
    "esc":"ESCAPE","escape":"ESCAPE","menu":"MENU",
}

def _norm(raw: str) -> str:
    s = raw.strip()
    return PYNPUT_MAP.get(s.lower(), s.upper())


# ── Colour schemes ────────────────────────────────────────────────────────────
# Each scheme: list of (pos 0-1, (R,G,B)) stops
SCHEMES = {
    "Purple Glow": [
        (0.00, (22,  20,  48)),
        (0.20, (55,  38, 155)),
        (0.45, (100, 70, 240)),
        (0.70, (180,140, 255)),
        (0.90, (220,200, 255)),
        (1.00, (255,255, 255)),
    ],
    "Fire": [
        (0.00, (18,  10,   5)),
        (0.20, (100,  20,   0)),
        (0.45, (200,  60,   0)),
        (0.70, (255, 160,   0)),
        (0.90, (255, 220,  80)),
        (1.00, (255, 255, 200)),
    ],
    "Ice": [
        (0.00, (5,   15,  30)),
        (0.20, (0,   60, 120)),
        (0.45, (0,  150, 210)),
        (0.70, (80, 210, 255)),
        (0.90, (180,240, 255)),
        (1.00, (230,250, 255)),
    ],
    "Matrix": [
        (0.00, (5,   15,   5)),
        (0.20, (0,   60,  10)),
        (0.45, (0,  160,  30)),
        (0.70, (50, 220,  50)),
        (0.90, (160,255, 120)),
        (1.00, (220,255, 200)),
    ],
    "Mono": [
        (0.00, (10,  12,  18)),
        (0.25, (40,  48,  65)),
        (0.55, (100,115, 145)),
        (0.80, (180,190, 210)),
        (1.00, (240,245, 255)),
    ],
}

def _scheme_color(t: float, scheme_stops: list, brightness: float = 1.0):
    """Interpolate colour at position t (0-1) through scheme stops."""
    t = max(0.0, min(1.0, t))
    for i in range(len(scheme_stops)-1):
        t0,(r0,g0,b0) = scheme_stops[i]
        t1,(r1,g1,b1) = scheme_stops[i+1]
        if t0 <= t <= t1:
            f = (t-t0)/(t1-t0) if t1>t0 else 0
            r = int((r0+(r1-r0)*f) * brightness)
            g = int((g0+(g1-g0)*f) * brightness)
            b = int((b0+(b1-b0)*f) * brightness)
            return (min(255,r), min(255,g), min(255,b))
    r,g,b = scheme_stops[-1][1]
    return (min(255,int(r*brightness)), min(255,int(g*brightness)), min(255,int(b*brightness)))

def _fg_for_bg(r,g,b):
    """White text on dark bg, dark text on light bg."""
    luminance = 0.299*r + 0.587*g + 0.114*b
    return "#ffffff" if luminance < 140 else "#0a0a0a"


# ── Key cap widget ────────────────────────────────────────────────────────────
class _KeyCap(QWidget):
    """
    Paints itself with:
      - heat colour background (from chosen scheme)
      - key label (centred, or shifted up when % shown)
      - % text bottom-right corner
      - subtle glow border when hot
    Only repaints when heat/pct changes (dirty flag).
    """
    def __init__(self, display: str, w_units: float, parent=None):
        super().__init__(parent)
        self._display = display
        self._heat    = 0.0
        self._pct_str = ""
        self._scheme  = SCHEMES["Purple Glow"]
        self._bright  = 1.0
        self._show_pct= True
        self._dirty   = True
        w = max(6, int(UNIT * w_units - 5))
        h = UNIT - 5
        self.setFixedSize(w, h)

    def set_scheme(self, stops: list):
        self._scheme = stops; self._dirty = True; self.update()

    def set_brightness(self, b: float):
        self._bright = b; self._dirty = True; self.update()

    def set_show_pct(self, v: bool):
        self._show_pct = v; self._dirty = True; self.update()

    def update_heat(self, t: float, pct_str: str):
        if (abs(t - self._heat) < 0.004 and pct_str == self._pct_str
                and not self._dirty):
            return
        self._heat    = t
        self._pct_str = pct_str
        self._dirty   = False
        self.update()

    def paintEvent(self, ev):
        p = QPainter(self)
        p.setRenderHints(QPainter.Antialiasing | QPainter.TextAntialiasing)
        w, h = self.width(), self.height()

        # Background colour
        if self._heat <= 0.005:
            bg_r, bg_g, bg_b = 18, 20, 34
        else:
            bg_r, bg_g, bg_b = _scheme_color(self._heat, self._scheme, self._bright)

        bg_c = QColor(bg_r, bg_g, bg_b)
        fg_c = QColor(_fg_for_bg(bg_r, bg_g, bg_b))

        # Key body
        path = QPainterPath()
        path.addRoundedRect(QRectF(0, 0, w, h), 5, 5)
        p.fillPath(path, bg_c)

        # Border – dim for cold, glowing for hot
        if self._heat > 0.5:
            glow = QColor(bg_r, bg_g, bg_b); glow.setAlpha(160)
            pen = QPen(glow, 2)
        elif self._heat > 0.15:
            col = QColor(bg_r, bg_g, bg_b).lighter(130); col.setAlpha(100)
            pen = QPen(col, 1)
        else:
            pen = QPen(QColor(T.BORDER_SOFT), 1)
        p.setPen(pen); p.drawPath(path)

        # Glow halo for very hot keys
        if self._heat > 0.6:
            halo = QColor(bg_r, bg_g, bg_b); halo.setAlpha(int(self._heat * 70))
            p.setPen(QPen(halo, 4)); p.drawPath(path)

        # ── Label ──
        has_pct = self._show_pct and bool(self._pct_str) and self._heat > 0.01
        disp    = self._display

        p.setPen(fg_c)
        key_fsize = 7 if len(disp) > 4 else (8 if len(disp) > 2 else 10)
        key_weight = QFont.Bold if self._heat > 0.35 else QFont.Medium
        p.setFont(QFont(T.FONT_FAMILY, key_fsize, key_weight))

        if has_pct:
            # Key label in upper portion
            p.drawText(QRectF(1, 0, w-2, h*0.60), Qt.AlignCenter, disp)
            # % label in bottom strip
            pct_col = QColor(fg_c); pct_col.setAlpha(220)
            p.setPen(pct_col)
            p.setFont(QFont(T.FONT_FAMILY, 6, QFont.Bold))
            p.drawText(QRectF(1, h*0.58, w-3, h*0.42),
                       Qt.AlignRight | Qt.AlignVCenter, self._pct_str)
        else:
            p.drawText(QRectF(0, 0, w, h), Qt.AlignCenter, disp)


# ── Keyboard widget ────────────────────────────────────────────────────────────
class KeyboardHeatmapWidget(QWidget):
    """
    Full keyboard grid.  Call refresh(counts, show_pct, scheme_name, brightness)
    to update all keys.
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self._key_map  = {}   # canonical_name -> [_KeyCap, ...]
        self._scheme   = SCHEMES["Purple Glow"]
        self._bright   = 1.0
        self._show_pct = True

        root = QHBoxLayout(self)
        root.setSpacing(18); root.setContentsMargins(4, 4, 4, 4)
        root.addLayout(self._build(MAIN_ROWS))
        root.addWidget(self._sep())
        root.addLayout(self._build(NAV_ROWS))
        root.addWidget(self._sep())
        root.addLayout(self._build(NUMPAD_ROWS))
        root.addStretch(1)

    def _sep(self):
        f = QFrame(); f.setFixedWidth(1)
        f.setStyleSheet(f"background:{T.BORDER_SOFT};"); return f

    def _build(self, rows):
        block = QVBoxLayout(); block.setSpacing(5)
        for row in rows:
            hl = QHBoxLayout(); hl.setSpacing(5)
            if not row:
                sp = QLabel(); sp.setFixedSize(UNIT, UNIT-5)
                sp.setStyleSheet("background:transparent;")
                hl.addWidget(sp); hl.addStretch(1); block.addLayout(hl); continue
            for disp, span, canon in row:
                if span <= 0: continue
                if disp == "" and canon is None:
                    hl.addSpacing(int(UNIT*span)); continue
                cap = _KeyCap(disp, span)
                hl.addWidget(cap)
                if canon:
                    self._key_map.setdefault(canon, []).append(cap)
            hl.addStretch(0); block.addLayout(hl)
        return block

    # ── Public refresh ───────────────────────────────────────────────────────
    def apply_scheme(self, name: str):
        self._scheme = SCHEMES.get(name, SCHEMES["Purple Glow"])
        for caps in self._key_map.values():
            for c in caps: c.set_scheme(self._scheme)

    def apply_brightness(self, pct: int):
        self._bright = 0.3 + pct/100 * 0.7
        for caps in self._key_map.values():
            for c in caps: c.set_brightness(self._bright)

    def apply_show_pct(self, v: bool):
        self._show_pct = v
        for caps in self._key_map.values():
            for c in caps: c.set_show_pct(v)

    def refresh(self, counts: dict):
        """Update every key's heat and pct from normalised counts dict."""
        if not counts:
            for caps in self._key_map.values():
                for c in caps: c.update_heat(0.0, "")
            return
        total      = max(1, sum(counts.values()))
        max_single = max(counts.values())

        for canon, caps in self._key_map.items():
            cnt = counts.get(canon, 0)
            # Log scale so low-use keys still show colour
            t = math.log1p(cnt) / math.log1p(max_single) if max_single > 0 else 0
            pct_str = f"{cnt/total*100:.1f}%" if (self._show_pct and cnt > 0) else ""
            for cap in caps:
                cap.update_heat(t, pct_str)

    def clear(self):
        for caps in self._key_map.values():
            for c in caps: c.update_heat(0.0, "")


# ── Gradient legend ────────────────────────────────────────────────────────────
class _GradientBar(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._scheme = SCHEMES["Purple Glow"]
        self.setFixedHeight(12)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

    def set_scheme(self, stops):
        self._scheme = stops; self.update()

    def paintEvent(self, ev):
        p = QPainter(self)
        p.setRenderHints(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        grad = QLinearGradient(0, 0, w, 0)
        for pos, (r, g, b) in self._scheme:
            grad.setColorAt(pos, QColor(r, g, b))
        path = QPainterPath()
        path.addRoundedRect(QRectF(0, 0, w, h), 5, 5)
        p.fillPath(path, grad)


# ── Scheme pill buttons ────────────────────────────────────────────────────────
class _SchemePill(QPushButton):
    def __init__(self, name: str, color: str, parent=None):
        super().__init__(name, parent)
        self._col = color
        self.setCheckable(True)
        self.setCursor(Qt.PointingHandCursor)
        self.setFixedHeight(28)
        self._refresh()

    def setChecked(self, v):
        super().setChecked(v); self._refresh()

    def _refresh(self):
        if self.isChecked():
            self.setStyleSheet(f"""
                QPushButton {{
                    background:{self._col}; color:#fff;
                    border-radius:14px; font-size:11px; font-weight:700;
                    padding:0 14px;
                }}
            """)
        else:
            self.setStyleSheet(f"""
                QPushButton {{
                    background:{T.CARD_BG_2}; color:{T.TEXT_MUTED};
                    border:1px solid {T.BORDER}; border-radius:14px;
                    font-size:11px; padding:0 14px;
                }}
                QPushButton:hover {{ color:{T.TEXT_PRIMARY}; border-color:{self._col}; }}
            """)


SCHEME_COLORS = {
    "Purple Glow": T.ACCENT_PURPLE,
    "Fire":        "#f97316",
    "Ice":         "#22d3ee",
    "Matrix":      "#22c55e",
    "Mono":        "#8b93a7",
}

DEMO_COUNTS = {
    "SPACE":1500,"E":980,"T":840,"A":790,"O":720,"I":660,"N":640,
    "S":610,"H":560,"R":520,"W":470,"D":430,"L":410,"C":380,
    "U":350,"M":300,"F":280,"G":270,"Y":250,"P":220,"B":200,
    "V":175,"K":160,"ENTER":340,"BACKSPACE":310,"SHIFT":460,
    "CTRL":195,"TAB":155,"X":85,"J":72,"Q":62,"Z":48,
    "1":90,"2":85,"3":80,"4":75,"5":70,
    "F5":40,"F11":35,"ESC":110,"ALT":130,
}


class KeyboardPage(QWidget):
    title    = "Keyboard"
    subtitle = "Live keystroke analytics and heatmap"
    has_own_header = True

    def __init__(self, parent=None):
        super().__init__(parent)
        outer = QVBoxLayout(self); outer.setContentsMargins(0, 0, 0, 0)
        body  = QWidget()
        lay   = QVBoxLayout(body); lay.setContentsMargins(4, 4, 4, 4); lay.setSpacing(18)

        lay.addLayout(page_header(self.title, self.subtitle,
                                  "Keyboard (system)", "Connected", "⌨"))

        # ── Stat cards ────────────────────────────────────────────────────
        stats = QHBoxLayout(); stats.setSpacing(14)
        self._c_total  = StatCard("⌨", T.ACCENT_PURPLE,"Total Keystrokes","0",   "Session",[0]*12)
        self._c_unique = StatCard("🔑", T.ACCENT_BLUE,  "Unique Keys",     "0",   "pressed", [0]*12)
        self._c_kps    = StatCard("⚡", T.ACCENT_TEAL,  "Keys / sec",      "0",   "Live",    [0]*12)
        self._c_back   = StatCard("⌫", T.ACCENT_PINK,  "Backspaces",      "0",   "Session", [0]*12)
        self._c_space  = StatCard("▬", T.ACCENT_ORANGE, "Spacebar",        "0",   "presses", [0]*12)
        for c in (self._c_total,self._c_unique,self._c_kps,self._c_back,self._c_space):
            stats.addWidget(c)
        lay.addLayout(stats)

        # ── KPS chart ────────────────────────────────────────────────────
        chart_p = Panel("Keystrokes Per Second (Live)", small_dropdown("60 s"))
        self._chart = MultiLineChart(
            [{"name":"KPS","color":T.ACCENT_PURPLE,"data":[0]*60}], [], y_max=20)
        chart_p.body.addWidget(self._chart)
        lay.addWidget(chart_p)

        # ── Heatmap panel ─────────────────────────────────────────────────
        kb_panel = Panel("Live Key Heatmap")

        # ── Control row ──────────────────────────────────────────────────
        ctrl_row = QHBoxLayout(); ctrl_row.setSpacing(10)

        # Scheme pills
        scheme_row = QHBoxLayout(); scheme_row.setSpacing(6)
        self._scheme_group  = QButtonGroup(self)
        self._scheme_pills  = {}
        for idx, (name, col) in enumerate(SCHEME_COLORS.items()):
            pill = _SchemePill(name, col)
            pill.setChecked(idx == 0)
            pill.clicked.connect(lambda checked, n=name: self._on_scheme(n))
            self._scheme_group.addButton(pill, idx)
            scheme_row.addWidget(pill)
            self._scheme_pills[name] = pill
        ctrl_row.addLayout(scheme_row)
        ctrl_row.addStretch(1)

        # % toggle
        self._pct_btn = QPushButton("% Labels  ON")
        self._pct_btn.setCheckable(True); self._pct_btn.setChecked(True)
        self._pct_btn.setCursor(Qt.PointingHandCursor)
        self._pct_btn.setFixedHeight(28)
        self._pct_btn.clicked.connect(self._on_pct_toggle)
        self._style_toggle(self._pct_btn, True)
        ctrl_row.addWidget(self._pct_btn)

        # Reset
        reset_btn = QPushButton("↺ Reset")
        reset_btn.setCursor(Qt.PointingHandCursor)
        reset_btn.setFixedHeight(28)
        reset_btn.setStyleSheet(f"""
            QPushButton {{
                background:{T.CARD_BG_2}; color:{T.TEXT_MUTED};
                border:1px solid {T.BORDER}; border-radius:14px;
                font-size:11px; padding:0 14px;
            }}
            QPushButton:hover {{ color:{T.TEXT_PRIMARY}; }}
        """)
        reset_btn.clicked.connect(self._on_reset)
        ctrl_row.addWidget(reset_btn)

        kb_panel.body.addLayout(ctrl_row)

        # Brightness slider row
        bright_row = QHBoxLayout(); bright_row.setSpacing(10)
        bri_lbl = QLabel("Brightness")
        bri_lbl.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:11px;")
        self._bright_slider = QSlider(Qt.Horizontal)
        self._bright_slider.setRange(20, 100); self._bright_slider.setValue(85)
        self._bright_slider.setFixedHeight(18)
        self._bright_slider.setStyleSheet(f"""
            QSlider::groove:horizontal {{
                background:{T.BORDER}; height:4px; border-radius:2px;
            }}
            QSlider::handle:horizontal {{
                background:{T.ACCENT_PURPLE}; width:14px; height:14px;
                margin:-5px 0; border-radius:7px;
            }}
            QSlider::sub-page:horizontal {{
                background:{T.ACCENT_PURPLE}; border-radius:2px;
            }}
        """)
        self._bright_slider.valueChanged.connect(self._on_brightness)
        self._bright_val_lbl = QLabel("85%")
        self._bright_val_lbl.setStyleSheet(f"color:{T.TEXT_SECOND}; font-size:11px;")
        self._bright_val_lbl.setFixedWidth(34)
        bright_row.addWidget(bri_lbl); bright_row.addWidget(self._bright_slider,1)
        bright_row.addWidget(self._bright_val_lbl)
        kb_panel.body.addLayout(bright_row)

        # Keyboard scroll area
        sa = QScrollArea()
        sa.setWidgetResizable(True); sa.setFrameShape(QScrollArea.NoFrame)
        sa.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        sa.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        sa.setFixedHeight(UNIT * 7 + 60)
        sa.setStyleSheet("QScrollArea { background: transparent; }")

        self._kb = KeyboardHeatmapWidget()
        sa.setWidget(self._kb)
        kb_panel.body.addWidget(sa)

        # Gradient legend
        leg_row = QHBoxLayout(); leg_row.setSpacing(10)
        cold_l = QLabel("0%"); cold_l.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:10px;")
        hot_l  = QLabel("Most used"); hot_l.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:10px;")
        self._grad_bar = _GradientBar()
        leg_row.addWidget(cold_l); leg_row.addWidget(self._grad_bar, 1); leg_row.addWidget(hot_l)
        kb_panel.body.addLayout(leg_row)

        # Colour meanings
        col_row = QHBoxLayout(); col_row.setSpacing(18)
        for label, pct_range in [("Cold","0%"),("Warm","1–5%"),("Hot",">10%"),("Peak","Most pressed")]:
            col = QVBoxLayout(); col.setSpacing(2)
            l1 = QLabel(label); l1.setStyleSheet(f"color:{T.TEXT_PRIMARY}; font-size:11px; font-weight:600;")
            l2 = QLabel(pct_range); l2.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:10px;")
            col.addWidget(l1); col.addWidget(l2)
            col_row.addLayout(col)
        col_row.addStretch(1)
        kb_panel.body.addLayout(col_row)

        self._hint_lbl = QLabel("ℹ  Install pynput for real tracking. Showing demo data.")
        self._hint_lbl.setStyleSheet(f"color:{T.ACCENT_ORANGE}; font-size:10px;")
        self._hint_lbl.setVisible(False)
        kb_panel.body.addWidget(self._hint_lbl)

        lay.addWidget(kb_panel)

        # ── Bottom: top keys + categories ─────────────────────────────────
        bot = QHBoxLayout(); bot.setSpacing(18)

        # Top-10 table
        top_p = Panel("Top Pressed Keys – Share of Total")
        hdr   = QHBoxLayout()
        for txt, w in [("#",26),("Key",0),("Count",62),("Share %",70)]:
            l = QLabel(txt); l.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:10px; font-weight:600;")
            if w: l.setFixedWidth(w); l.setAlignment(Qt.AlignRight)
            hdr.addWidget(l, 0 if w else 1)
        top_p.body.addLayout(hdr)

        self._top_rows  = []
        self._bar_fracs = [0.0] * 10
        for i in range(10):
            row  = QHBoxLayout(); row.setSpacing(8)
            rank = QLabel(str(i+1)); rank.setFixedWidth(26)
            rank.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:11px; font-weight:600;")

            key_l= QLabel("—")
            key_l.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
            key_l.setStyleSheet(f"color:{T.TEXT_PRIMARY}; font-size:12px; font-weight:700;")

            bar_bg= QFrame(); bar_bg.setFixedHeight(4)
            bar_bg.setStyleSheet(f"background:{T.BORDER}; border-radius:2px;")
            bar_fg= QFrame(bar_bg)
            bar_fg.setStyleSheet(f"background:{T.ACCENT_PURPLE}; border-radius:2px;")
            bar_bg.resizeEvent = (lambda e, bg=bar_bg, fg=bar_fg, idx=i:
                fg.setGeometry(0,0,int(bg.width()*self._bar_fracs[idx]),bg.height()))

            cnt_l= QLabel("0"); cnt_l.setFixedWidth(62); cnt_l.setAlignment(Qt.AlignRight)
            cnt_l.setStyleSheet(f"color:{T.TEXT_SECOND}; font-size:11px;")
            pct_l= QLabel("—%"); pct_l.setFixedWidth(70); pct_l.setAlignment(Qt.AlignRight)
            pct_l.setStyleSheet(f"color:{T.ACCENT_PURPLE}; font-size:12px; font-weight:700;")

            row.addWidget(rank); row.addWidget(key_l,1); row.addWidget(bar_bg,2)
            row.addWidget(cnt_l); row.addWidget(pct_l)
            top_p.body.addLayout(row)
            self._top_rows.append((key_l, bar_fg, bar_bg, cnt_l, pct_l))
        top_p.body.addStretch(1)
        bot.addWidget(top_p, 3)

        # Category donut
        cat_p = Panel("Key Categories")
        self._donut = DonutChart(
            [1,1,1,1,1],
            [T.ACCENT_PURPLE,T.ACCENT_BLUE,T.ACCENT_TEAL,T.ACCENT_ORANGE,"#f0d020"],
            "Keys","—")
        cat_row = QHBoxLayout(); cat_row.addWidget(self._donut)
        self._cat_vals = {}
        cat_leg = QVBoxLayout(); cat_leg.setSpacing(10)
        for lbl, col in [("Letters",T.ACCENT_PURPLE),("Numbers",T.ACCENT_BLUE),
                          ("Symbols",T.ACCENT_TEAL),("Modifiers",T.ACCENT_ORANGE),
                          ("Special","#f0d020")]:
            r = QHBoxLayout(); r.setSpacing(8)
            dot = QLabel(); dot.setFixedSize(10,10)
            dot.setStyleSheet(f"background:{col}; border-radius:5px;")
            r.addWidget(dot)
            l = QLabel(lbl); l.setStyleSheet(f"color:{T.TEXT_PRIMARY}; font-size:12px;")
            r.addWidget(l,1)
            v = QLabel("—"); v.setStyleSheet(f"color:{col}; font-size:11px; font-weight:700;")
            r.addWidget(v)
            cat_leg.addLayout(r)
            self._cat_vals[lbl] = v
        cat_row.addLayout(cat_leg,1)
        cat_p.body.addLayout(cat_row)
        cat_p.body.addStretch(1)
        bot.addWidget(cat_p, 2)
        lay.addLayout(bot)

        lay.addStretch(1)
        outer.addWidget(scrollable(body))

        # ── Internal state ─────────────────────────────────────────────────
        self._LETTERS   = set("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
        self._NUMBERS   = set("0123456789")
        self._MODIFIERS = {"SHIFT","CTRL","ALT","CMD","CAPS_LOCK","MENU","WIN"}
        self._SPECIALS  = {"SPACE","ENTER","BACKSPACE","TAB","ESCAPE","DELETE",
                           "INSERT","HOME","END","PAGE_UP","PAGE_DOWN",
                           "UP","DOWN","LEFT","RIGHT",
                           *[f"F{i}" for i in range(1,13)]}
        self._hm_tick        = 0
        self._show_pct_state = True
        self._current_scheme = "Purple Glow"
        self._norm_counts    = {}

        # Load demo data immediately so heatmap shows on first open
        self._kb.refresh(DEMO_COUNTS)

    # ── Control handlers ──────────────────────────────────────────────────────
    def _on_scheme(self, name: str):
        self._current_scheme = name
        self._kb.apply_scheme(name)
        self._grad_bar.set_scheme(SCHEMES[name])
        # Update bar colours in top table
        col = SCHEME_COLORS[name]
        for _, bar_fg, _, _, pct_l in self._top_rows:
            bar_fg.setStyleSheet(f"background:{col}; border-radius:2px;")
            pct_l.setStyleSheet(f"color:{col}; font-size:12px; font-weight:700;")

    def _on_pct_toggle(self):
        self._show_pct_state = self._pct_btn.isChecked()
        self._style_toggle(self._pct_btn, self._show_pct_state)
        self._pct_btn.setText("% Labels  ON" if self._show_pct_state else "% Labels  OFF")
        self._kb.apply_show_pct(self._show_pct_state)
        # Force full refresh
        if self._norm_counts:
            self._kb.refresh(self._norm_counts)

    def _on_brightness(self, val: int):
        self._bright_val_lbl.setText(f"{val}%")
        self._kb.apply_brightness(val)

    def _on_reset(self):
        self._norm_counts = {}
        self._kb.clear()
        for key_l, bar_fg, _, cnt_l, pct_l in self._top_rows:
            key_l.setText("—"); cnt_l.setText("0"); pct_l.setText("—%")
            self._bar_fracs[self._top_rows.index(
                (key_l,bar_fg,bar_fg.parent(),cnt_l,pct_l)
            )] = 0.0

    @staticmethod
    def _style_toggle(btn: QPushButton, on: bool):
        if on:
            btn.setStyleSheet(f"""
                QPushButton {{
                    background:{T.ACCENT_PURPLE}; color:#fff;
                    border-radius:14px; font-size:11px; font-weight:700;
                    padding:0 14px;
                }}
            """)
        else:
            btn.setStyleSheet(f"""
                QPushButton {{
                    background:{T.CARD_BG_2}; color:{T.TEXT_MUTED};
                    border:1px solid {T.BORDER}; border-radius:14px;
                    font-size:11px; padding:0 14px;
                }}
                QPushButton:hover {{ color:{T.TEXT_PRIMARY}; }}
            """)

    # ── Live update ────────────────────────────────────────────────────────────
    def on_snapshot(self, snap: dict):
        kt     = snap["key_total"]; kd = snap["key_delta"]
        counts = snap.get("key_counts", {})
        ok     = snap["pynput_ok"]
        self._hint_lbl.setVisible(not ok)

        # Normalise key names
        norm = {}
        for raw, cnt in counts.items():
            k = _norm(raw)
            norm[k] = norm.get(k, 0) + cnt

        use_counts = norm if norm else (DEMO_COUNTS if not ok else {})
        if use_counts:
            self._norm_counts = use_counts

        bs   = norm.get("BACKSPACE", 0)
        sp   = norm.get("SPACE", 0)
        uniq = len(norm)

        self._c_total.update_live( f"{kt:,}",  "total",    snap["key_hist"][-12:])
        self._c_unique.update_live(str(uniq),   "keys",     [uniq]*12)
        self._c_kps.update_live(   str(kd),     "per sec",  snap["key_hist"][-12:])
        self._c_back.update_live(  f"{bs:,}",   "erases",   [0]*12)
        self._c_space.update_live( f"{sp:,}",   "presses",  [0]*12)

        self._chart.update_series([
            {"name":"KPS","color":T.ACCENT_PURPLE,"data":snap["key_hist"]}
        ])

        # Heatmap: refresh every 2 ticks → 500ms effective
        self._hm_tick += 1
        if self._hm_tick % 2 == 0 and use_counts:
            self._kb.refresh(use_counts)

        # ── Top keys table ─────────────────────────────────────────────────
        total = max(1, sum(use_counts.values()))
        if use_counts:
            sorted_k = sorted(use_counts.items(), key=lambda x: x[1], reverse=True)
            max_cnt  = sorted_k[0][1] if sorted_k else 1
            for i, (key_l, bar_fg, bar_bg, cnt_l, pct_l) in enumerate(self._top_rows):
                if i < len(sorted_k):
                    name, cnt = sorted_k[i]
                    key_l.setText(name[:12])
                    cnt_l.setText(f"{cnt:,}")
                    pct_l.setText(f"{cnt/total*100:.2f}%")
                    self._bar_fracs[i] = cnt / max(1, max_cnt)
                    bar_fg.setGeometry(0,0,
                        int(bar_bg.width()*self._bar_fracs[i]),bar_bg.height())
                else:
                    key_l.setText("—"); cnt_l.setText("0"); pct_l.setText("—%")
                    self._bar_fracs[i] = 0.0

        # ── Categories ─────────────────────────────────────────────────────
        cats = {k:0 for k in ("Letters","Numbers","Symbols","Modifiers","Special")}
        for name, cnt in use_counts.items():
            if name   in self._LETTERS:   cats["Letters"]   += cnt
            elif name in self._NUMBERS:   cats["Numbers"]   += cnt
            elif name in self._MODIFIERS: cats["Modifiers"] += cnt
            elif name in self._SPECIALS:  cats["Special"]   += cnt
            else:                         cats["Symbols"]   += cnt
        cat_tot = max(1, sum(cats.values()))
        for lbl, v in self._cat_vals.items():
            c = cats[lbl]
            v.setText(f"{c/cat_tot*100:.0f}%  ({c:,})")
