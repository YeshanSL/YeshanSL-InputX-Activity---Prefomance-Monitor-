"""
SystemMonitor v3 – accurate game detection, smooth, non-blocking.

Game detection rules (strict):
  1. EXACT basename match against GAME_DB (e.g. "valorant-win64-shipping.exe")
  2. Whole-word boundary fuzzy match only — keyword must appear as a
     standalone word or with a separator (-, _, .) in the proc name.
     This stops "cod" from matching "discord" or "cod" from "records".
  3. Minimum 6-character keywords for fuzzy to avoid short false hits.
"""
import time, collections, platform, os, re, subprocess
from datetime import datetime
from threading import Lock

try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False

from PySide6.QtCore import QThread, Signal, QObject

HISTORY      = 60
PROC_REFRESH = 3   # seconds between full proc scans
GPU_REFRESH  = 5   # seconds between nvidia-smi calls

# ── Game database – EXACT exe basename (lowercase) only ──────────────────────
GAME_DB = {
    # Valorant
    "valorant-win64-shipping.exe": ("Valorant",         "♦", "#ef4d77"),
    "valorant.exe":                ("Valorant",         "♦", "#ef4d77"),
    # Apex
    "r5apex.exe":                  ("Apex Legends",     "Ⓐ", "#c0392b"),
    # CoD – full exe names, never partial
    "cod.exe":                     ("Call of Duty",     "◆", "#4a5568"),
    "codmw2.exe":                  ("CoD MW2",          "◆", "#4a5568"),
    "codmw3.exe":                  ("CoD MW3",          "◆", "#4a5568"),
    "codmw.exe":                   ("CoD MW",           "◆", "#4a5568"),
    "codbo6.exe":                  ("CoD BO6",          "◆", "#4a5568"),
    # CS
    "csgo.exe":                    ("CS:GO",            "◎", "#f5a623"),
    "cs2.exe":                     ("CS2",              "◎", "#f5a623"),
    # Overwatch
    "overwatch.exe":               ("Overwatch 2",      "◉", "#f97316"),
    "overwatch2.exe":              ("Overwatch 2",      "◉", "#f97316"),
    # Battle Royale
    "fortniteclient-win64-shipping.exe": ("Fortnite",   "★", "#3b82f6"),
    "pubg.exe":                    ("PUBG",             "◐", "#f59e0b"),
    "tslgame.exe":                 ("PUBG",             "◐", "#f59e0b"),
    # Destiny
    "destiny2.exe":                ("Destiny 2",        "◈", "#6366f1"),
    # RPG
    "cyberpunk2077.exe":           ("Cyberpunk 2077",   "◈", "#facc15"),
    "eldenring.exe":               ("Elden Ring",       "⚔", "#c0a060"),
    "witcher3.exe":                ("Witcher 3",        "⚔", "#22c55e"),
    # Open world
    "gtav.exe":                    ("GTA V",            "◆", "#14c8a6"),
    "gta5.exe":                    ("GTA V",            "◆", "#14c8a6"),
    "gta_sa.exe":                  ("GTA SA",           "◆", "#14c8a6"),
    "rdr2.exe":                    ("RDR2",             "★", "#a52a2a"),
    # MOBA / strategy
    "league of legends.exe":       ("League of Legends","⚡", "#c89b3c"),
    "leagueoflegends.exe":         ("League of Legends","⚡", "#c89b3c"),
    "dota2.exe":                   ("Dota 2",           "🏆","#ef4444"),
    "starcraft2.exe":              ("StarCraft II",     "◆", "#3b82f6"),
    "sc2.exe":                     ("StarCraft II",     "◆", "#3b82f6"),
    # Sandbox
    "javaw.exe":                   ("Minecraft",        "▦", "#5c8a3c"),
    "minecraft.exe":               ("Minecraft",        "▦", "#5c8a3c"),
    "minecraftlauncher.exe":       ("Minecraft",        "▦", "#5c8a3c"),
    "rocketleague.exe":            ("Rocket League",    "⚽","#1f4fd6"),
    "terraria.exe":                ("Terraria",         "🌿","#22c55e"),
    # Racing
    "f12023.exe":                  ("F1 23",            "🏎","#e10600"),
    "f12024.exe":                  ("F1 24",            "🏎","#e10600"),
    "assettocorsa.exe":            ("Assetto Corsa",    "🏎","#ff6b35"),
    "acs.exe":                     ("Assetto Corsa",    "🏎","#ff6b35"),
    # Launchers (only exact names)
    "steam.exe":                   ("Steam",            "🎮","#1b2838"),
    "epicgameslauncher.exe":       ("Epic Games",       "🎮","#0078f2"),
    "battlenet.exe":               ("Battle.net",       "🎮","#00aeff"),
    "battle.net.exe":              ("Battle.net",       "🎮","#00aeff"),
    "upc.exe":                     ("Ubisoft Connect",  "🎮","#0070f3"),
    "ubisoftconnect.exe":          ("Ubisoft Connect",  "🎮","#0070f3"),
    "origin.exe":                  ("EA App/Origin",    "🎮","#f56c2d"),
    "eadesktop.exe":               ("EA App",           "🎮","#f56c2d"),
    # Fighting
    "tekken8.exe":                 ("Tekken 8",         "🥊","#ef4444"),
    "streetfighter6.exe":          ("Street Fighter 6", "🥊","#ef4444"),
    "mkx.exe":                     ("Mortal Kombat X",  "🥊","#ef4444"),
}

# ── Fuzzy list – ONLY long, unambiguous tokens ────────────────────────────────
# Rules enforced in _detect_game:
#   • keyword length >= 6 chars
#   • must match as a whole word (surrounded by non-alphanum or at boundary)
# "cod", "cs2", "epic", "apex" are deliberately NOT here – too short / ambiguous
GAME_FUZZY = [
    ("valorant",       "Valorant",         "♦", "#ef4d77"),
    ("fortnite",       "Fortnite",         "★", "#3b82f6"),
    ("minecraft",      "Minecraft",        "▦", "#5c8a3c"),
    ("overwatch",      "Overwatch 2",      "◉", "#f97316"),
    ("cyberpunk",      "Cyberpunk 2077",   "◈", "#facc15"),
    ("eldenring",      "Elden Ring",       "⚔", "#c0a060"),
    ("witcher3",       "Witcher 3",        "⚔", "#22c55e"),
    ("rocketleague",   "Rocket League",    "⚽","#1f4fd6"),
    ("destiny2",       "Destiny 2",        "◈", "#6366f1"),
    ("starcraft",      "StarCraft",        "◆", "#3b82f6"),
    ("leagueoflegends","League of Legends","⚡", "#c89b3c"),
    ("terraria",       "Terraria",         "🌿","#22c55e"),
    ("battlefield",    "Battlefield",      "▣", "#22c55e"),
    ("apexlegends",    "Apex Legends",     "Ⓐ", "#c0392b"),
    ("counterstrike",  "Counter-Strike",   "◎", "#f5a623"),
    ("diabloiv",       "Diablo IV",        "💀","#c0392b"),
    ("diablo4",        "Diablo IV",        "💀","#c0392b"),
    ("palworld",       "Palworld",         "🌏","#22c55e"),
    ("helldivers",     "Helldivers 2",     "★", "#facc15"),
    ("baldursgate",    "Baldur's Gate 3",  "⚔", "#6366f1"),
]

# Compile whole-word pattern for each fuzzy keyword
_FUZZY_PATTERNS = [
    (re.compile(r'(?<![a-z0-9])' + re.escape(kw) + r'(?![a-z0-9])', re.I),
     name, icon, color)
    for kw, name, icon, color in GAME_FUZZY
]


def _detect_game(proc_name: str, exe_path: str = ""):
    """
    Return (game_name, icon, color) or None.
    Uses exact DB match first, then strict whole-word fuzzy.
    """
    low = proc_name.lower().strip()

    # 1. Exact exe basename match
    if low in GAME_DB:
        return GAME_DB[low]

    if exe_path:
        base = os.path.basename(exe_path).lower()
        if base in GAME_DB:
            return GAME_DB[base]

    # 2. Whole-word fuzzy (patterns pre-compiled above)
    for pattern, name, icon, color in _FUZZY_PATTERNS:
        if pattern.search(low):
            return (name, icon, color)

    return None


class SystemMonitor(QObject):
    updated = Signal(dict)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._thread = QThread(self)
        self._worker = _Worker()
        self._worker.moveToThread(self._thread)
        self._thread.started.connect(self._worker.run)
        self._worker.updated.connect(self.updated)

    def start(self):  self._thread.start()
    def stop(self):
        self._worker.stop()
        self._thread.quit()
        self._thread.wait(3000)


class _Worker(QObject):
    updated = Signal(dict)

    def __init__(self):
        super().__init__()
        self._running   = False
        self._lock      = Lock()

        H = HISTORY
        self._cpu_hist    = collections.deque([0.0]*H, maxlen=H)
        self._ram_hist    = collections.deque([0.0]*H, maxlen=H)
        self._dl_hist     = collections.deque([0.0]*H, maxlen=H)
        self._ul_hist     = collections.deque([0.0]*H, maxlen=H)
        self._ping_hist   = collections.deque([15]*H,  maxlen=H)
        self._disk_r_hist = collections.deque([0.0]*H, maxlen=H)
        self._disk_w_hist = collections.deque([0.0]*H, maxlen=H)
        self._mouse_hist  = collections.deque([0]*H,   maxlen=H)
        self._key_hist    = collections.deque([0]*H,   maxlen=H)

        # Input state
        self._mouse_total = 0;  self._mouse_prev = 0
        self._key_total   = 0;  self._key_prev   = 0
        self._scroll_total= 0
        self._mouse_dist  = 0.0
        self._prev_pos    = None
        self._key_counts  = {}   # name -> count

        # Caches
        self._proc_cache  = []
        self._game_cache  = []
        self._proc_last   = 0.0
        self._net_prev    = None;  self._net_time  = None
        self._disk_prev   = None;  self._disk_time = None
        self._gpu_name    = None;  self._gpu_pct   = 0
        self._gpu_last    = 0.0

        self._session_start = time.time()
        self._pynput_ok = False
        self._setup_pynput()

    # ── pynput ───────────────────────────────────────────────────────────
    def _setup_pynput(self):
        try:
            from pynput import mouse as pm, keyboard as pk

            def on_click(x, y, btn, pressed):
                if pressed:
                    with self._lock: self._mouse_total += 1

            def on_scroll(x, y, dx, dy):
                with self._lock: self._scroll_total += 1

            def on_move(x, y):
                with self._lock:
                    if self._prev_pos:
                        px, py = self._prev_pos
                        d = ((x-px)**2+(y-py)**2)**0.5 / 96 * 0.0254
                        self._mouse_dist += d
                    self._prev_pos = (x, y)

            def on_press(key):
                with self._lock:
                    self._key_total += 1
                    try:
                        name = (key.char.upper()
                                if hasattr(key,'char') and key.char
                                else key.name.upper())
                    except Exception:
                        name = str(key).replace("Key.","").upper()
                    self._key_counts[name] = self._key_counts.get(name,0) + 1

            self._ml = pm.Listener(on_click=on_click, on_scroll=on_scroll, on_move=on_move)
            self._kl = pk.Listener(on_press=on_press)
            self._ml.daemon = True; self._kl.daemon = True
            self._ml.start(); self._kl.start()
            self._pynput_ok = True
        except Exception:
            self._pynput_ok = False

    # ── GPU (non-blocking, every GPU_REFRESH s) ───────────────────────────
    def _refresh_gpu(self):
        now = time.time()
        if now - self._gpu_last < GPU_REFRESH:
            return
        self._gpu_last = now
        try:
            out = subprocess.check_output(
                ["nvidia-smi","--query-gpu=name,utilization.gpu",
                 "--format=csv,noheader,nounits"],
                timeout=1, stderr=subprocess.DEVNULL).decode().strip()
            name, pct = out.split(",")
            self._gpu_name = name.strip(); self._gpu_pct = int(pct.strip())
        except Exception:
            self._gpu_name = None; self._gpu_pct = 0

    # ── Process + game scan (every PROC_REFRESH s) ────────────────────────
    def _refresh_procs(self):
        now = time.time()
        if now - self._proc_last < PROC_REFRESH:
            return
        self._proc_last = now
        if not HAS_PSUTIL:
            return
        procs, games = [], []
        try:
            attrs = ["name","cpu_percent","memory_percent","status"]
            for p in psutil.process_iter(attrs):
                try:
                    info = p.info
                    if info["status"] in ("zombie","dead"):
                        continue
                    name = (info["name"] or "").strip()
                    cpu  = info["cpu_percent"] or 0.0
                    mem  = info["memory_percent"] or 0.0
                    if not name:
                        continue
                    procs.append((name, cpu, mem, ""))
                    g = _detect_game(name)
                    if g:
                        games.append({"name":g[0],"icon":g[1],"color":g[2],
                                      "proc":name,"cpu":cpu,"mem":mem})
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
            procs.sort(key=lambda x: x[1], reverse=True)
        except Exception:
            pass

        self._proc_cache = procs[:12]
        # Deduplicate games by name
        seen, uniq = set(), []
        for g in games:
            if g["name"] not in seen:
                seen.add(g["name"]); uniq.append(g)
        self._game_cache = uniq

    # ── Main run loop ─────────────────────────────────────────────────────
    def run(self):
        self._running = True
        if HAS_PSUTIL:
            psutil.cpu_percent(interval=None)   # prime
        while self._running:
            t0   = time.time()
            snap = self._collect()
            self.updated.emit(snap)
            # Sleep remainder of 1-second slot
            elapsed = time.time() - t0
            sleep   = max(0.05, 1.0 - elapsed)
            time.sleep(sleep)

    def stop(self):
        self._running = False
        if self._pynput_ok:
            try: self._ml.stop()
            except: pass
            try: self._kl.stop()
            except: pass

    # ── Data collection ───────────────────────────────────────────────────
    def _collect(self):
        now  = time.time()
        snap = {}

        # CPU – blocking 0.2 s in worker thread (never stalls GUI)
        if HAS_PSUTIL:
            cpu_pct   = psutil.cpu_percent(interval=0.2)
            cpu_freq  = psutil.cpu_freq()
            cpu_cores = psutil.cpu_count(logical=False) or 1
            cpu_logic = psutil.cpu_count(logical=True)  or 1
            cpu_info  = platform.processor() or platform.machine() or "CPU"
            per_core  = psutil.cpu_percent(percpu=True, interval=None)
        else:
            cpu_pct=0; cpu_freq=None; cpu_cores=1; cpu_logic=1
            cpu_info="Unknown"; per_core=[]

        self._cpu_hist.append(cpu_pct)
        snap.update({
            "cpu_pct":   round(cpu_pct,1),
            "cpu_freq":  f"{cpu_freq.current/1000:.2f} GHz" if cpu_freq else "—",
            "cpu_cores": cpu_cores, "cpu_logic": cpu_logic,
            "cpu_info":  cpu_info[:40],
            "cpu_hist":  list(self._cpu_hist),
            "cpu_cores_pct": per_core,
        })

        # RAM
        if HAS_PSUTIL:
            vm = psutil.virtual_memory()
            ram_pct   = vm.percent
            ram_used  = vm.used  / (1024**3)
            ram_total = vm.total / (1024**3)
            ram_avail = vm.available / (1024**3)
        else:
            ram_pct=0; ram_used=0; ram_total=0; ram_avail=0

        self._ram_hist.append(ram_pct)
        snap.update({
            "ram_pct":   round(ram_pct,1),
            "ram_used":  f"{ram_used:.1f}",
            "ram_total": f"{ram_total:.0f}",
            "ram_avail": f"{ram_avail:.1f}",
            "ram_hist":  list(self._ram_hist),
        })

        # Disk usage + I/O speed
        if HAS_PSUTIL:
            try:
                du = psutil.disk_usage("/")
                disk_pct   = du.percent
                disk_used  = du.used  / (1024**3)
                disk_total = du.total / (1024**3)
            except Exception:
                disk_pct=0; disk_used=0; disk_total=0
            try:
                dio = psutil.disk_io_counters()
                if self._disk_prev and dio:
                    dt    = now - self._disk_time
                    r_mb  = (dio.read_bytes  - self._disk_prev.read_bytes)  / dt / (1024**2)
                    w_mb  = (dio.write_bytes - self._disk_prev.write_bytes) / dt / (1024**2)
                    r_mb  = max(0, r_mb); w_mb = max(0, w_mb)
                else:
                    r_mb = w_mb = 0.0
                self._disk_prev = dio; self._disk_time = now
            except Exception:
                r_mb = w_mb = 0.0
        else:
            disk_pct=0; disk_used=0; disk_total=0; r_mb=0; w_mb=0

        self._disk_r_hist.append(round(r_mb,2))
        self._disk_w_hist.append(round(w_mb,2))
        snap.update({
            "disk_pct":    round(disk_pct,1),
            "disk_used":   f"{disk_used:.0f}",
            "disk_total":  f"{disk_total:.0f}",
            "disk_r_mb":   round(r_mb,2),
            "disk_w_mb":   round(w_mb,2),
            "disk_r_hist": list(self._disk_r_hist),
            "disk_w_hist": list(self._disk_w_hist),
        })

        # GPU (cached)
        self._refresh_gpu()
        snap["gpu_pct"]  = self._gpu_pct
        snap["gpu_name"] = self._gpu_name or "No discrete GPU"

        # Network
        if HAS_PSUTIL:
            try:
                net = psutil.net_io_counters()
                if self._net_prev and net:
                    dt      = now - self._net_time
                    dl_mbps = max(0,(net.bytes_recv-self._net_prev.bytes_recv)/dt/131072)
                    ul_mbps = max(0,(net.bytes_sent-self._net_prev.bytes_sent)/dt/131072)
                else:
                    dl_mbps = ul_mbps = 0.0
                self._net_prev = net; self._net_time = now
                ip4 = "—"
                for iface, addrs in psutil.net_if_addrs().items():
                    for a in addrs:
                        if hasattr(a,'family') and a.family.name=="AF_INET":
                            if not a.address.startswith("127."):
                                ip4 = a.address; break
                    if ip4 != "—": break
            except Exception:
                dl_mbps=ul_mbps=0.0; ip4="—"
        else:
            dl_mbps=ul_mbps=0.0; ip4="—"

        self._dl_hist.append(round(dl_mbps,2))
        self._ul_hist.append(round(ul_mbps,2))
        # Ping estimate
        dl_win = list(self._dl_hist)[-5:]
        avg    = sum(dl_win)/len(dl_win) if dl_win else 0
        ping   = max(5, 20 - int(avg*0.5))
        self._ping_hist.append(ping)

        snap.update({
            "dl_mbps":   round(dl_mbps,2),
            "ul_mbps":   round(ul_mbps,2),
            "ping_ms":   ping,
            "net_ip":    ip4,
            "dl_hist":   list(self._dl_hist),
            "ul_hist":   list(self._ul_hist),
            "ping_hist": list(self._ping_hist),
        })

        # Processes + games (cached)
        self._refresh_procs()
        snap["top_procs"]       = [(n,c,m) for n,c,m,e in self._proc_cache]
        snap["top_procs_full"]  = list(self._proc_cache)
        snap["running_games"]   = list(self._game_cache)

        # Input (thread-safe snapshot)
        with self._lock:
            mt   = self._mouse_total
            md   = mt - self._mouse_prev
            self._mouse_prev = mt
            self._mouse_hist.append(md)
            kt   = self._key_total
            kd   = kt - self._key_prev
            self._key_prev   = kt
            self._key_hist.append(kd)
            sc   = self._scroll_total
            dist = self._mouse_dist
            self._mouse_dist = 0.0
            key_counts = dict(self._key_counts)

        snap.update({
            "mouse_clicks": mt, "mouse_delta":  md,
            "mouse_hist":   list(self._mouse_hist),
            "scroll_total": sc, "mouse_dist_m": round(dist,4),
            "key_total":    kt, "key_delta":    kd,
            "key_hist":     list(self._key_hist),
            "key_counts":   key_counts,
            "pynput_ok":    self._pynput_ok,
        })

        # Uptime + datetime
        uptime_sec = int(now - self._session_start)
        h, rem = divmod(uptime_sec, 3600); m, s = divmod(rem, 60)
        dt = datetime.now()
        snap.update({
            "uptime":     f"{h:02d}h {m:02d}m {s:02d}s",
            "uptime_sec": uptime_sec,
            "date_str":   dt.strftime("%B %d, %Y"),
            "day_str":    dt.strftime("%A"),
            "time_str":   dt.strftime("%I:%M:%S %p"),
            "hour":       dt.hour,
        })
        return snap
