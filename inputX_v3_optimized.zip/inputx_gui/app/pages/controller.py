from PySide6.QtCore import Qt
from PySide6.QtGui import QPainter, QColor, QPen, QBrush, QPainterPath, QFont
from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QPushButton

from .. import theme as T
from ..widgets import (StatCard, Panel, link_label, info_row, StickRadar,
                        SimpleSlider, ToggleSwitch, soft_shadow)
from .dashboard import scrollable
from .mouse import page_header


# -------------------------------------------------------------------------
class GamepadDiagram(QWidget):
    """Stylized Xbox-style gamepad silhouette with labeled face buttons,
    sticks, d-pad, view/menu and guide button — echoes the reference photo."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(260)

    def paintEvent(self, ev):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        cx, cy = w / 2, h / 2 - 6

        # ---- body silhouette: main shell + two grip "wings" ----
        body = QPainterPath()
        body.addRoundedRect(cx - 150, cy - 48, 300, 96, 48, 48)
        grip_l = QPainterPath()
        grip_l.addEllipse(cx - 168, cy + 6, 92, 92)
        grip_r = QPainterPath()
        grip_r.addEllipse(cx + 76, cy + 6, 92, 92)
        shell = body.united(grip_l).united(grip_r)

        p.setPen(Qt.NoPen)
        p.setBrush(QColor("#181c28"))
        p.drawPath(shell)
        p.setPen(QPen(QColor("#262c3d"), 1.4))
        p.setBrush(Qt.NoBrush)
        p.drawPath(shell)

        # subtle top highlight strip
        hl = QPainterPath()
        hl.addRoundedRect(cx - 140, cy - 44, 280, 30, 20, 20)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(255, 255, 255, 8))
        p.drawPath(hl)

        # ---- left stick (upper-left) ----
        lsx, lsy = cx - 96, cy - 6
        self._stick(p, lsx, lsy, 30)

        # ---- d-pad (lower-left) ----
        dpx, dpy = cx - 96, cy + 52
        p.setPen(Qt.NoPen)
        p.setBrush(QColor("#0e1018"))
        p.drawRoundedRect(int(dpx - 17), int(dpy - 6), 34, 12, 3, 3)
        p.drawRoundedRect(int(dpx - 6), int(dpy - 17), 12, 34, 3, 3)
        p.setBrush(QColor("#262c3d"))
        p.drawRoundedRect(int(dpx - 16), int(dpy - 5), 32, 10, 2, 2)
        p.drawRoundedRect(int(dpx - 5), int(dpy - 16), 10, 32, 2, 2)

        # ---- right stick (lower-right, offset from buttons) ----
        rsx, rsy = cx + 22, cy + 46
        self._stick(p, rsx, rsy, 28)

        # ---- ABXY diamond (upper-right) ----
        f = QFont(T.FONT_FAMILY, 9, QFont.Bold)
        p.setFont(f)
        btns = [
            ("Y", cx + 96, cy - 38, "#e8c52a"),
            ("X", cx + 70, cy - 12, "#3b82f6"),
            ("B", cx + 122, cy - 12, "#ef4444"),
            ("A", cx + 96, cy + 14, "#22c55e"),
        ]
        for label, x, y, color in btns:
            p.setPen(QPen(QColor(color), 1.8))
            p.setBrush(QColor("#0e1018"))
            p.drawEllipse(int(x - 13), int(y - 13), 26, 26)
            p.setPen(QColor(color))
            p.drawText(int(x - 13), int(y - 13), 26, 26, Qt.AlignCenter, label)

        # ---- view / menu pills ----
        p.setPen(Qt.NoPen)
        p.setBrush(QColor("#0e1018"))
        p.drawRoundedRect(int(cx - 30), int(cy - 36), 16, 10, 5, 5)
        p.drawRoundedRect(int(cx + 14), int(cy - 36), 16, 10, 5, 5)
        p.setBrush(QColor(T.TEXT_MUTED))
        p.drawRect(int(cx - 27), int(cy - 32), 10, 2)
        p.drawEllipse(int(cx + 17), int(cy - 33), 4, 4)
        p.drawEllipse(int(cx + 23), int(cy - 33), 4, 4)

        # ---- guide / xbox-style button ----
        glow = QColor(T.ACCENT_PURPLE)
        glow.setAlpha(60)
        p.setBrush(glow)
        p.drawEllipse(int(cx - 17), int(cy - 60), 34, 34)
        p.setBrush(QColor(T.ACCENT_PURPLE))
        p.drawEllipse(int(cx - 11), int(cy - 54), 22, 22)

        # ---- triggers/bumpers hint strips on top edge ----
        p.setBrush(QColor("#262c3d"))
        p.drawRoundedRect(int(cx - 142), int(cy - 58), 46, 10, 4, 4)
        p.drawRoundedRect(int(cx + 96), int(cy - 58), 46, 10, 4, 4)

    @staticmethod
    def _stick(p, x, y, outer_r):
        p.setPen(Qt.NoPen)
        p.setBrush(QColor("#0c0e15"))
        p.drawEllipse(int(x - outer_r), int(y - outer_r), int(outer_r * 2), int(outer_r * 2))
        p.setBrush(QColor("#20253a"))
        p.drawEllipse(int(x - outer_r + 4), int(y - outer_r + 4), int(outer_r * 2 - 8), int(outer_r * 2 - 8))
        inner_r = outer_r * 0.62
        p.setBrush(QColor(T.ACCENT_PURPLE))
        p.drawEllipse(int(x - inner_r), int(y - inner_r), int(inner_r * 2), int(inner_r * 2))


def _legend_columns():
    legend_row = QHBoxLayout()
    groups = [
        [("LT", "Left Trigger"), ("LB", "Left Bumper"), ("VIEW", "View"),
         ("LS", "Left Stick Click"), ("D-PAD", "D-Pad")],
        [("RT", "Right Trigger"), ("RB", "Right Bumper"), ("MENU", "Menu"),
         ("Y", "Y Button"), ("B", "B Button"), ("A", "A Button"), ("X", "X Button"),
         ("RS", "Right Stick Click")],
    ]
    for grp in groups:
        col = QVBoxLayout()
        for code, name in grp:
            r = QHBoxLayout()
            c = QLabel(code)
            c.setFixedWidth(46)
            c.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:10px; background-color:{T.CARD_BG_2}; "
                            f"border-radius:4px; padding:2px 4px;")
            n = QLabel(name)
            n.setStyleSheet(f"color:{T.TEXT_SECOND}; font-size:11px;")
            r.addWidget(c); r.addWidget(n); r.addStretch(1)
            col.addLayout(r)
        legend_row.addLayout(col)
    return legend_row


def pill_button(text, primary=False):
    btn = QPushButton(text)
    btn.setCursor(Qt.PointingHandCursor)
    if primary:
        btn.setStyleSheet(f"""
            QPushButton {{
                color:white; font-size:12px; font-weight:600; background-color:{T.ACCENT_PURPLE};
                border-radius:8px; padding:9px 16px;
            }}
            QPushButton:hover {{ background-color:#6b5be0; }}
        """)
    else:
        btn.setStyleSheet(f"""
            QPushButton {{
                color:{T.TEXT_SECOND}; font-size:12px; background-color:{T.CARD_BG_2};
                border:1px solid {T.BORDER}; border-radius:8px; padding:9px 14px;
            }}
            QPushButton:hover {{ color:{T.TEXT_PRIMARY}; border-color:{T.ACCENT_PURPLE}; }}
        """)
    return btn


# -------------------------------------------------------------------------
class TabBar(QWidget):
    """Clickable underline tab strip (Button Mapping / Stick Calibration / ...)."""
    def __init__(self, labels, on_change, parent=None):
        super().__init__(parent)
        self._buttons = []
        self._on_change = on_change
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(26)
        for i, label in enumerate(labels):
            btn = QPushButton(label)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setFlat(True)
            btn.clicked.connect(lambda checked, idx=i: self._select(idx))
            lay.addWidget(btn)
            self._buttons.append(btn)
        lay.addStretch(1)
        self._select(0, fire=False)

    def _select(self, idx, fire=True):
        for i, btn in enumerate(self._buttons):
            active = i == idx
            color = T.ACCENT_PURPLE if active else T.TEXT_SECOND
            weight = 700 if active else 500
            border = f"border-bottom: 2px solid {T.ACCENT_PURPLE};" if active else "border-bottom: 2px solid transparent;"
            btn.setStyleSheet(f"""
                QPushButton {{
                    color:{color}; font-size:13px; font-weight:{weight};
                    background:transparent; padding-bottom:8px; {border}
                }}
            """)
        if fire:
            self._on_change(idx)


# -------------------------------------------------------------------------
class ControllerPage(QWidget):
    title = "Controller"
    subtitle = "Configure and monitor your controller"
    has_own_header = True

    def __init__(self, parent=None):
        super().__init__(parent)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        body = QWidget()
        lay = QVBoxLayout(body)
        lay.setContentsMargins(4, 4, 4, 4)
        lay.setSpacing(18)

        lay.addLayout(page_header(self.title, self.subtitle, "Xbox Wireless Controller", "Connected", "🎮"))

        stats = QHBoxLayout()
        stats.setSpacing(16)
        stats.addWidget(StatCard("🎮", T.ACCENT_BLUE, "Controller Status", "Connected", "Xbox Wireless Controller",
                                  [6,6,6,6,6,6,6,6,6,6,6,6], up=True))
        stats.addWidget(StatCard("🔋", T.ACCENT_TEAL, "Battery Level", "80%", "Charging",
                                  [3,4,5,6,7,7,8,8,8,8,8,8], up=True))
        stats.addWidget(StatCard("⏱", T.ACCENT_PURPLE, "Input Latency", "5 ms", "Excellent",
                                  [6,5,6,4,5,4,5,3,4,3,4,3], up=False))
        stats.addWidget(StatCard("≈", T.ACCENT_PURPLE, "Vibration", "Medium", "Intensity",
                                  [5,5,5,5,5,5,5,5,5,5,5,5], up=True))
        stats.addWidget(StatCard("◎", T.ACCENT_BLUE, "Polling Rate", "1000 Hz", "Ultra-fast",
                                  [8,8,8,8,8,8,8,8,8,8,8,8], up=True))
        lay.addLayout(stats)

        self.tab_labels = ["Button Mapping", "Stick Calibration", "Triggers", "Vibration", "Lighting"]
        self.tab_titles = ["Button Layout", "Stick Calibration", "Trigger Settings",
                            "Vibration Settings", "Lighting"]
        tabbar = TabBar(self.tab_labels, self._on_tab_changed)
        lay.addWidget(tabbar)
        lay.addWidget(_divider())

        mid = QHBoxLayout()
        mid.setSpacing(18)

        self.main_panel = Panel(self.tab_titles[0])
        mid.addWidget(self.main_panel, 2)

        self.profile_panel = Panel("Controller Profile", link_label("+ New Profile"))
        for name, sub, active, icon in [
            ("Default Profile", "Active", True, "★"),
            ("FPS Profile", "Last used: 2 days ago", False, "🎯"),
            ("Racing Profile", "Last used: 5 days ago", False, "🏎"),
            ("Fighting Profile", "Last used: 1 week ago", False, "🥊"),
            ("Adventure Profile", "Last used: 2 weeks ago", False, "🗺"),
        ]:
            row = QHBoxLayout()
            ic = QLabel(icon); ic.setFixedSize(28, 28); ic.setAlignment(Qt.AlignCenter)
            ic.setStyleSheet(f"background-color:{T.CARD_BG_2}; border-radius:7px; font-size:13px;")
            row.addWidget(ic)
            col = QVBoxLayout(); col.setSpacing(2)
            n = QLabel(name); n.setStyleSheet(f"color:{T.TEXT_PRIMARY}; font-size:12px; font-weight:600;")
            s = QLabel(sub); s.setStyleSheet(f"color:{T.ACCENT_GREEN if active else T.TEXT_MUTED}; font-size:10px;")
            col.addWidget(n); col.addWidget(s)
            row.addLayout(col, 1)
            self.profile_panel.body.addLayout(row)
        self.profile_panel.body.addStretch(1)
        mid.addWidget(self.profile_panel, 1)
        lay.addLayout(mid)

        bottom = QHBoxLayout()
        bottom.setSpacing(18)

        self.monitor_panel = Panel("Input Monitor")
        hint = QLabel("Press any button or move any stick to test")
        hint.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:11px;")
        self.monitor_panel.body.addWidget(hint)
        btn_row = QHBoxLayout()
        self._monitor_buttons = {}
        for b in ["A","B","X","Y","LB","RB","LT","RT","MENU","VIEW","L3","R3"]:
            l = QPushButton(b)
            l.setFixedSize(40, 28)
            l.setCursor(Qt.PointingHandCursor)
            l.setStyleSheet(self._mon_btn_style(False))
            l.pressed.connect(lambda btn=b: self._flash_button(btn, True))
            l.released.connect(lambda btn=b: self._flash_button(btn, False))
            btn_row.addWidget(l)
            self._monitor_buttons[b] = l
        btn_row.addStretch(1)
        self.monitor_panel.body.addLayout(btn_row)

        sticks_row = QHBoxLayout()
        sticks_row.setSpacing(28)
        for label, key in [("Left Stick", "left"), ("Right Stick", "right")]:
            col = QVBoxLayout()
            col.setSpacing(6)
            t = QLabel(label)
            t.setAlignment(Qt.AlignCenter)
            t.setStyleSheet(f"color:{T.TEXT_SECOND}; font-size:11px; font-weight:600;")
            col.addWidget(t)
            radar = StickRadar(0, 0)
            col.addWidget(radar)
            xy = QLabel("X: 0%   Y: 0%")
            xy.setAlignment(Qt.AlignCenter)
            xy.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:10px;")
            col.addWidget(xy)
            sticks_row.addLayout(col)
            if key == "left":
                self.left_radar, self.left_xy = radar, xy
            else:
                self.right_radar, self.right_xy = radar, xy
        sticks_row.addStretch(1)
        self.monitor_panel.body.addLayout(sticks_row)
        self.monitor_panel.body.addStretch(1)
        bottom.addWidget(self.monitor_panel, 2)

        actions_panel = Panel("Quick Actions")
        actions_defs = [
            ("⟲", "Calibrate Controller", "Calibrate sticks and triggers"),
            ("🩺", "Test Controller", "Run full diagnostic test"),
            ("⬆", "Update Firmware", "Check for firmware updates"),
            ("⬇", "Backup Configuration", "Save current configuration"),
        ]
        for icon, label, sub in actions_defs:
            row = self._clickable_action(icon, label, sub)
            actions_panel.body.addWidget(row)
        actions_panel.body.addStretch(1)
        bottom.addWidget(actions_panel, 1)
        lay.addLayout(bottom)

        lay.addStretch(1)
        outer.addWidget(scrollable(body))

        self._on_tab_changed(0)

    # -- tab content builders --------------------------------------------
    def _on_tab_changed(self, idx):
        self.main_panel.set_title(self.tab_titles[idx])
        self.main_panel.clear_body()
        builder = [self._build_button_mapping, self._build_stick_calibration,
                   self._build_triggers, self._build_vibration, self._build_lighting][idx]
        builder(self.main_panel.body)

    def _build_button_mapping(self, body):
        body.addWidget(GamepadDiagram())
        body.addLayout(_legend_columns())
        reset_row = QHBoxLayout()
        reset = pill_button("Reset to Default")
        edit = pill_button("Edit Mapping", primary=True)
        reset_row.addWidget(reset)
        reset_row.addStretch(1)
        reset_row.addWidget(edit)
        body.addLayout(reset_row)

    def _build_stick_calibration(self, body):
        hint = QLabel("Move each stick to its full range, then press Calibrate to save deadzones.")
        hint.setWordWrap(True)
        hint.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:11px;")
        body.addWidget(hint)
        row = QHBoxLayout()
        row.setSpacing(30)
        for label in ("Left Stick", "Right Stick"):
            col = QVBoxLayout()
            t = QLabel(label)
            t.setAlignment(Qt.AlignCenter)
            t.setStyleSheet(f"color:{T.TEXT_PRIMARY}; font-size:12px; font-weight:600;")
            col.addWidget(t)
            col.addWidget(StickRadar(0, 0))
            row.addLayout(col)
        body.addLayout(row)
        dz_row = QHBoxLayout()
        dz_label = QLabel("Deadzone")
        dz_label.setStyleSheet(f"color:{T.TEXT_SECOND}; font-size:12px;")
        dz_row.addWidget(dz_label)
        dz_row.addWidget(SimpleSlider(18, T.ACCENT_PURPLE), 1)
        body.addLayout(dz_row)
        body.addStretch(1)
        body.addWidget(pill_button("Calibrate Sticks", primary=True))

    def _build_triggers(self, body):
        for label, value, color in [("Left Trigger Sensitivity", 65, T.ACCENT_BLUE),
                                     ("Right Trigger Sensitivity", 65, T.ACCENT_BLUE),
                                     ("Trigger Deadzone", 12, T.ACCENT_PURPLE)]:
            row = QHBoxLayout()
            l = QLabel(label)
            l.setFixedWidth(170)
            l.setStyleSheet(f"color:{T.TEXT_SECOND}; font-size:12px;")
            row.addWidget(l)
            row.addWidget(SimpleSlider(value, color), 1)
            body.addLayout(row)
        hh_row = QHBoxLayout()
        hh_label = QLabel("Hair-Trigger Mode")
        hh_label.setStyleSheet(f"color:{T.TEXT_PRIMARY}; font-size:12px; font-weight:600;")
        hh_sub = QLabel("Register trigger pulls at the slightest press")
        hh_sub.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:10px;")
        col = QVBoxLayout(); col.setSpacing(2)
        col.addWidget(hh_label); col.addWidget(hh_sub)
        hh_row.addLayout(col, 1)
        hh_row.addWidget(ToggleSwitch(False))
        body.addLayout(hh_row)
        body.addStretch(1)

    def _build_vibration(self, body):
        for label, value, color in [("Overall Intensity", 70, T.ACCENT_PURPLE),
                                     ("Left Motor", 80, T.ACCENT_BLUE),
                                     ("Right Motor", 55, T.ACCENT_TEAL)]:
            row = QHBoxLayout()
            l = QLabel(label)
            l.setFixedWidth(120)
            l.setStyleSheet(f"color:{T.TEXT_SECOND}; font-size:12px;")
            row.addWidget(l)
            row.addWidget(SimpleSlider(value, color), 1)
            body.addLayout(row)
        en_row = QHBoxLayout()
        en_label = QLabel("Vibration Enabled")
        en_label.setStyleSheet(f"color:{T.TEXT_PRIMARY}; font-size:12px; font-weight:600;")
        col = QVBoxLayout(); col.setSpacing(2)
        col.addWidget(en_label)
        en_row.addLayout(col, 1)
        en_row.addWidget(ToggleSwitch(True))
        body.addLayout(en_row)
        body.addStretch(1)
        body.addWidget(pill_button("Test Vibration", primary=True))

    def _build_lighting(self, body):
        sub = QLabel("Customize the controller's LED accent (where supported).")
        sub.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:11px;")
        body.addWidget(sub)
        swatch_row = QHBoxLayout()
        for color in [T.ACCENT_PURPLE, T.ACCENT_BLUE, T.ACCENT_TEAL, T.ACCENT_ORANGE,
                      T.ACCENT_PINK, T.ACCENT_GREEN, "#ffffff"]:
            sw = QPushButton()
            sw.setFixedSize(28, 28)
            sw.setCursor(Qt.PointingHandCursor)
            sw.setStyleSheet(f"background-color:{color}; border-radius:14px; border: 2px solid {T.BORDER};")
            swatch_row.addWidget(sw)
        swatch_row.addStretch(1)
        body.addLayout(swatch_row)
        row = QHBoxLayout()
        l = QLabel("Brightness")
        l.setFixedWidth(120)
        l.setStyleSheet(f"color:{T.TEXT_SECOND}; font-size:12px;")
        row.addWidget(l)
        row.addWidget(SimpleSlider(85, T.ACCENT_PURPLE), 1)
        body.addLayout(row)
        mode_row = QHBoxLayout()
        m_label = QLabel("Breathing Effect")
        m_label.setStyleSheet(f"color:{T.TEXT_PRIMARY}; font-size:12px; font-weight:600;")
        col = QVBoxLayout(); col.setSpacing(2)
        col.addWidget(m_label)
        mode_row.addLayout(col, 1)
        mode_row.addWidget(ToggleSwitch(False))
        body.addLayout(mode_row)
        body.addStretch(1)

    # -- small interactive bits -------------------------------------------
    def _mon_btn_style(self, active):
        bg = T.ACCENT_PURPLE if active else T.CARD_BG_2
        color = "white" if active else T.TEXT_SECOND
        return f"""
            QPushButton {{
                background-color:{bg}; color:{color}; border-radius:6px; font-size:10px; font-weight:600;
                border: 1px solid {T.BORDER if not active else T.ACCENT_PURPLE};
            }}
        """

    def _flash_button(self, name, pressed):
        btn = self._monitor_buttons.get(name)
        if btn:
            btn.setStyleSheet(self._mon_btn_style(pressed))

    def _clickable_action(self, icon, label, sub):
        row = QFrame()
        row.setCursor(Qt.PointingHandCursor)
        row.setStyleSheet(f"""
            QFrame {{ background-color: transparent; border-radius: 8px; }}
            QFrame:hover {{ background-color: {T.CARD_BG_2}; }}
        """)
        h = QHBoxLayout(row)
        h.setContentsMargins(4, 6, 4, 6)
        h.setSpacing(12)
        ic = QLabel(icon)
        ic.setFixedSize(32, 32)
        ic.setAlignment(Qt.AlignCenter)
        ic.setStyleSheet(f"background-color:{T.CARD_BG_2}; border-radius:8px; font-size:14px;")
        h.addWidget(ic)
        col = QVBoxLayout(); col.setSpacing(2)
        t = QLabel(label); t.setStyleSheet(f"color:{T.TEXT_PRIMARY}; font-size:13px; font-weight:600;")
        s = QLabel(sub); s.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:11px;")
        col.addWidget(t); col.addWidget(s)
        h.addLayout(col, 1)
        return row


def _divider():
    f = QFrame()
    f.setFixedHeight(1)
    f.setStyleSheet(f"background-color:{T.BORDER_SOFT};")
    return f


# Stub on_snapshot so the dispatcher doesn't crash
def _controller_on_snapshot(self, snap: dict):
    pass  # Controller page shows static UI + gamepad diagram; no live data needed

ControllerPage.on_snapshot = _controller_on_snapshot
