"""Network page – live download/upload/ping charts and connection details."""
from PySide6.QtCore    import Qt
from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame

from .. import theme as T
from ..widgets import (StatCard, MultiLineChart, ChartLegend, Panel,
                        link_label, small_dropdown, info_row)
from .dashboard import scrollable


class NetworkPage(QWidget):
    title    = "Network"
    subtitle = "Monitor your network performance and connectivity"

    def __init__(self, parent=None):
        super().__init__(parent)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        body = QWidget()
        lay  = QVBoxLayout(body)
        lay.setContentsMargins(4, 4, 4, 4)
        lay.setSpacing(18)

        # ── Stat cards ────────────────────────────────────────────────────────
        stats = QHBoxLayout(); stats.setSpacing(16)
        self._card_status = StatCard("🌐", T.ACCENT_TEAL,   "Network Status", "Connected",
                                      "Internet active", [6]*12)
        self._card_dl     = StatCard("↓",  T.ACCENT_TEAL,   "Download",      "0 Mbps", "—", [0]*12)
        self._card_ul     = StatCard("↑",  T.ACCENT_PURPLE, "Upload",        "0 Mbps", "—", [0]*12)
        self._card_ping   = StatCard("⟳",  T.ACCENT_BLUE,   "Ping",          "— ms",   "—", [0]*12)
        self._card_loss   = StatCard("🛡",  T.ACCENT_PINK,   "Packet Loss",   "0.0%",   "Good", [0]*12)
        for c in (self._card_status, self._card_dl, self._card_ul,
                  self._card_ping, self._card_loss):
            stats.addWidget(c)
        lay.addLayout(stats)

        # ── Chart + connection details ─────────────────────────────────────────
        mid = QHBoxLayout(); mid.setSpacing(18)
        chart_panel = Panel("Network Activity", small_dropdown("Live"))
        chart_panel.body.addWidget(ChartLegend([
            ("Download (Mbps)", T.ACCENT_TEAL),
            ("Upload (Mbps)",   T.ACCENT_PURPLE),
        ]))
        self._chart = MultiLineChart(
            [{"name": "Download", "color": T.ACCENT_TEAL,   "data": [0]*60},
             {"name": "Upload",   "color": T.ACCENT_PURPLE, "data": [0]*60}],
            [], y_max=100)
        chart_panel.body.addWidget(self._chart)
        mid.addWidget(chart_panel, 2)

        details_panel = Panel("Connection Details")
        self._detail_vals = {}
        for key, label, default in [
            ("ip4",  "Local IP",     "—"),
            ("type", "Type",         "Ethernet / Wi-Fi"),
            ("dl",   "Download",     "—"),
            ("ul",   "Upload",       "—"),
            ("ping", "Ping",         "—"),
        ]:
            row = QHBoxLayout()
            l = QLabel(label); l.setStyleSheet(f"color:{T.TEXT_MUTED}; font-size:11px;")
            v = QLabel(default); v.setAlignment(Qt.AlignRight)
            v.setStyleSheet(f"color:{T.TEXT_PRIMARY}; font-size:12px; font-weight:600;")
            row.addWidget(l); row.addStretch(1); row.addWidget(v)
            details_panel.body.addLayout(row)
            self._detail_vals[key] = v
        details_panel.body.addStretch(1)
        mid.addWidget(details_panel, 1)
        lay.addLayout(mid)

        # ── Speed test placeholder ─────────────────────────────────────────────
        bottom = QHBoxLayout(); bottom.setSpacing(18)

        test_panel = Panel("Speed Test")
        from PySide6.QtWidgets import QPushButton
        run_btn = QPushButton("▶  Run Speed Test (coming soon)")
        run_btn.setStyleSheet(f"""
            QPushButton {{
                color:white; background-color:{T.ACCENT_PURPLE};
                border-radius:8px; padding:10px 18px; font-size:12px; font-weight:600;
            }}
            QPushButton:hover {{ background-color:#6b5be0; }}
        """)
        test_panel.body.addWidget(run_btn)
        test_panel.body.addStretch(1)
        bottom.addWidget(test_panel, 1)

        alerts_panel = Panel("Network Alerts")
        self._alerts_box = QVBoxLayout()
        alerts_panel.body.addLayout(self._alerts_box)
        alerts_panel.body.addStretch(1)
        bottom.addWidget(alerts_panel, 1)
        lay.addLayout(bottom)

        lay.addStretch(1)
        outer.addWidget(scrollable(body))

        self._alert_count = 0

    def on_snapshot(self, snap: dict):
        dl  = snap["dl_mbps"]
        ul  = snap["ul_mbps"]
        png = snap["ping_ms"]

        self._card_dl.update_live(f"{dl} Mbps",  "live", snap["dl_hist"][-12:])
        self._card_ul.update_live(f"{ul} Mbps",  "live", snap["ul_hist"][-12:])
        self._card_ping.update_live(f"{png} ms", "live", snap["ping_hist"][-12:])

        self._chart.update_series([
            {"name": "Download", "color": T.ACCENT_TEAL,   "data": snap["dl_hist"]},
            {"name": "Upload",   "color": T.ACCENT_PURPLE, "data": snap["ul_hist"]},
        ])

        self._detail_vals["ip4"].setText(snap.get("net_ip", "—"))
        self._detail_vals["dl"].setText(f"{dl} Mbps")
        self._detail_vals["ul"].setText(f"{ul} Mbps")
        self._detail_vals["ping"].setText(f"{png} ms")

        # Simple alert for high bandwidth
        if dl > 50:
            self._add_alert("⚠", "#3a1f18", "High download usage",
                            f"{dl:.1f} Mbps")
        elif dl < 0.1 and snap["uptime_sec"] > 10:
            self._add_alert("✓", "#102a1c", "Network idle", "Low usage detected")

    def _add_alert(self, icon, bg, title, sub):
        if self._alert_count >= 5:
            # Clear oldest
            item = self._alerts_box.takeAt(0)
            if item and item.widget():
                item.widget().deleteLater()
        w = info_row(icon, bg, title, sub, "now")
        self._alerts_box.addWidget(w)
        self._alert_count = min(self._alert_count + 1, 5)
